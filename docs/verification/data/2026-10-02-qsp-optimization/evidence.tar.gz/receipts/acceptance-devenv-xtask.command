devenv --no-tui -j 1 -u 2 shell --clean -- bash -c 'CARGO_TARGET_DIR=<artifacts>/devenv-target CARGO_BUILD_JOBS=2 NEXTEST_TEST_THREADS=4 OMP_NUM_THREADS=2 cargo nextest run -p xtask --all-features'
