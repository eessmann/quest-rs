devenv --no-tui -j 1 -u 2 shell --clean -- bash -c 'CARGO_TARGET_DIR=<artifacts>/devenv-acceptance-target CARGO_BUILD_JOBS=2 cargo fmt --all -- --check'
