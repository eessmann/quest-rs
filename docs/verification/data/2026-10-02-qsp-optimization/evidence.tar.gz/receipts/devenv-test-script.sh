#!/nix/store/svx59425zxp552p2b8gm11qj5r09b56i-bash-5.3p15/bin/bash
set -euo pipefail
# Wait for the port to be open until the timeout is reached
wait_for_port() {
  local port=$1
  local timeout=${2:-15}

  if ! timeout "$timeout" bash -c "until /nix/store/g5bkw95rmg3gwwhd02n7ir0wl5slalwi-libressl-4.3.2-nc/bin/nc -z localhost $port 2>/dev/null; do sleep 0.5; done"; then
    echo "Error: Port $port did not become available within $timeout seconds."
    exit 1
  fi
}

# Wait for processes to be healthy
wait_for_processes() {
  local timeout=${1:-120}

  case "native" in
    "process-compose")
      echo "• Waiting for process-compose processes to be ready (timeout: $timeout seconds)..." >&2

      # TODO(sander): Update this to use the new wait command once it's available in process-compose
      # Pre-calculate which processes have readiness probes
      readiness_probes='{}'

      # Use a simple shell script that handles a single task
      process_compose_wait=/nix/store/wa4h4x9krb89xxp7js0zmyzz5zgfygwh-process-compose-wait

      timeout $timeout $process_compose_wait
      ;;
    "native")
      echo "• Waiting for native processes to be ready (timeout: $timeout seconds)..." >&2
      devenv processes wait --timeout $timeout
      echo "✓ All processes are ready" >&2
      ;;
    "")
      # No process manager configured, nothing to wait for
      ;;
    *)
      echo "✗ Unsupported process manager implementation: native" >&2
      return 1
      ;;
  esac
}

export -f wait_for_port
export -f wait_for_processes

cargo build --workspace --all-features --locked
cargo nextest run --workspace --all-features
cargo test --doc --workspace --all-features --locked
cargo nextest run -p quest-qsp --all-features --release --run-ignored only
cargo run --locked -p quest-rs --example minimal

if [ -f ./.test.sh ]; then
  echo "• Running .test.sh..."
  ./.test.sh
fi


