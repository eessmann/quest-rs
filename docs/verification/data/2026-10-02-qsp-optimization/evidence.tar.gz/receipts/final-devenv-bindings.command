devenv --no-tui -j 1 -u 2 shell --clean -- bash -c 'CARGO_TARGET_DIR=<artifacts>/devenv-target CARGO_BUILD_JOBS=2 OMP_NUM_THREADS=2 cargo run --locked -p xtask -- generate-quest-bindings --check'
