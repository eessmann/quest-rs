# devenv test failure propagation

Pinned devenv module source: `/nix/store/gckix6jfk492i2c79pyxsr3lh10s31vg-source`, revision `9272f920ccb6bfc72e87b3c712caffcf3cacecd8`. `src/modules/tests.nix:19-22` creates the test shell script with `set -euo pipefail` before `${config.enterTest}`.

Generated Linux test script `/nix/store/6kjdl5fd7gvnbyy163gh84si3yrrd49l-devenv-test` likewise has `set -euo pipefail` on line 2 before all four requested acceptance Cargo commands and minimal example. Preserved exact script `devenv-test-script.sh` in receipts. `devenv --no-tui -j 1 -u 2 build test` realized the script (exit 0) without running it or rerunning full tests.

A failed simple Cargo command exits immediately; later passing commands cannot mask failure. No explicit local errexit setting or source change is needed.
