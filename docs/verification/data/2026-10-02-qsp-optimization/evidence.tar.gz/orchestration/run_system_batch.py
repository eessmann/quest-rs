import pathlib, subprocess, sys
base=pathlib.Path(__file__).resolve().parent
cwd='<worktree>'
commands=[
 ('build',['cargo','build','--workspace','--all-features','--locked']),
 ('nextest',['cargo','nextest','run','--workspace','--all-features']),
 ('docs',['cargo','test','--doc','--workspace','--all-features','--locked']),
 ('release',['cargo','nextest','run','-p','quest-qsp','--all-features','--release','--run-ignored','only']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--','-D','warnings']),
 ('bindings',['cargo','run','--locked','-p','xtask','--','generate-quest-bindings','--check']),
 ('fmt',['cargo','fmt','--all','--','--check'])]
failed=[]
for label,cmd in commands:
 status=subprocess.run([sys.executable,str(base/'run_system.py'),'acceptance-system-'+label,cwd,*cmd]).returncode
 if status: failed.append(label)
print('FAILED CHECKS:',failed,flush=True)
sys.exit(bool(failed))
