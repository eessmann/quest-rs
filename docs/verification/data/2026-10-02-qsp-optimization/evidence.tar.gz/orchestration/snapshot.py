import pathlib,shutil,sys
base=pathlib.Path('<artifacts>')
work=pathlib.Path('<worktree>')
label=sys.argv[1]
target=base/('snapshot-'+label)
if target.exists(): raise SystemExit('snapshot already exists')
shutil.copytree(base/'baseline',target)
crates=['quest-qsp']+(['quest-numerics'] if label=='abc' else [])
for crate in crates:
 shutil.rmtree(target/'crates'/crate)
 shutil.copytree(work/'crates'/crate,target/'crates'/crate,ignore=shutil.ignore_patterns('target','__pycache__'))
print(target)
