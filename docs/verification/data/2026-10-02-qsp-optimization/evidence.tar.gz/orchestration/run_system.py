import json, os, pathlib, subprocess, sys, time
base=pathlib.Path('<artifacts>')
label, cwd, *command=sys.argv[1:]
env={'HOME':os.environ['HOME'],'USER':'erich','LANG':'C.UTF-8','PATH':'<home>/.cargo/bin:/usr/lib64/mpich/bin:/usr/bin:/bin','QUEST_ROOT':'<home>/Projects/opt/quest','CMAKE_PREFIX_PATH':'/usr/lib64/mpich','PKG_CONFIG_PATH':'/usr/lib64/mpich/lib/pkgconfig','MPICC':'/usr/lib64/mpich/bin/mpicc','CC':'/usr/bin/cc','CXX':'/usr/bin/c++','CLANG':'/usr/bin/clang','LIBCLANG_PATH':'/usr/lib64','CARGO_TARGET_DIR':str(base/'system-target'),'CARGO_BUILD_JOBS':'2','NEXTEST_TEST_THREADS':'4','OMP_NUM_THREADS':'2'}
record={'command':command,'cwd':cwd,'environment':env,'started':time.time()}
prefix=base/'receipts'/label
if prefix.with_suffix('.json').exists(): raise SystemExit('refusing to overwrite receipt')
with prefix.with_suffix('.log').open('w') as log:
 p=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=p.returncode,elapsed=time.time()-record['started'])
prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
sys.exit(p.returncode)
