import gzip, hashlib, io, json, pathlib, tarfile
base=pathlib.Path(__file__).resolve().parent
w=pathlib.Path('<worktree>')
out=w/'docs/verification/data/2026-10-02-qsp-optimization'
replacements=[(str(w),'<worktree>'),(str(base),'<artifacts>'),('<repo>','<repo>'),('<home>','<home>'),('<home>','<home>'), ('"USER": "<user>"', '"USER": "<user>"'), ('USER=<user>','USER=<user>'), ('Linux <host> ', 'Linux <host> '), ('/run/user/<uid>/', '/run/user/<uid>/')]
items={}
def add(path,name):
 if path.is_file(): items[name]=path
for p in base.iterdir():
 if p.suffix in ('.py','.sh'): add(p,'orchestration/'+p.name)
for p in (base/'receipts').iterdir():
 if p.is_file(): add(p,'receipts/'+p.name)
for p in (w/'.superpowers/sdd/2026-10-02-all-features-qsp').iterdir():
 if p.suffix in ('.md','.log','.json'): add(p,'reviews-and-focused-checks/'+p.name)
for lane in ['system','devenv']:
 for p in (base/(lane+'-consumers')).glob('*.log'): add(p,lane+'-consumers/'+p.name)
for phase,folder in [('campaign','campaign'),('preparation','measurements')]:
 parent=base/folder
 for p in parent.iterdir():
  if p.is_file(): add(p,phase+'/'+p.name)
 for label in ['baseline','a','ab','abc']:
  variant=parent/label
  if not variant.exists(): continue
  for p in variant.iterdir():
   if p.is_file() and p.name!='observer': add(p,phase+'/'+label+'/'+p.name)
  if phase=='campaign':
   for p in (variant/'package').rglob('*'):
    if p.is_file(): add(p,phase+'/'+label+'/package/'+str(p.relative_to(variant/'package')))
manifest=[]
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name,path in sorted(items.items()):
    original=path.read_bytes()
    text=original.decode()
    for a,b in replacements: text=text.replace(a,b)
    data=text.encode()
    entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
    tar.addfile(entry,io.BytesIO(data))
    manifest.append({'path':name,'original_sha256':hashlib.sha256(original).hexdigest(),'archived_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(out/'evidence-manifest.json').write_text(json.dumps({'path_normalization':'User-specific paths are replaced by <worktree>, <artifacts>, <repo>, and <home>; original capture hashes are retained.','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest},indent=2)+'\n')
print('archived',len(items),'files;',archive.stat().st_size,'bytes')
