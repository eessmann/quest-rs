import json,os,pathlib,subprocess,sys
base=pathlib.Path(__file__).resolve().parent
w='<worktree>'
cmd=['cargo','nextest','list','-p','quest-sys','--all-features','--message-format','json']
r=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
(base/'receipts/acceptance2-system-mpi-list.stdout').write_text(r.stdout)
(base/'receipts/acceptance2-system-mpi-list.stderr').write_text(r.stderr)
print(json.dumps({'command':cmd,'exit_code':r.returncode}),flush=True)
r.check_returncode()
data=json.loads(r.stdout)
suites=data['rust-suites']
entries=[v for k,v in suites.items() if v['binary-name']=='mpi']
assert len(entries)==1, list(suites)
suite=entries[0]
print(json.dumps(suite),flush=True)
binary=suite['binary-path']
for ranks,name in [('2','mpi_collective_preflight_rejects_mismatch_on_every_rank'),('4','mpi_subgroups_and_excluded_ranks_preserve_contexts')]:
 cmd=['timeout','90s','/usr/lib64/mpich/bin/mpiexec','-n',ranks,binary,'--exact',name,'--nocapture','--test-threads=1']
 print(json.dumps({'command':cmd,'QUEST_SYS_MPI_CASE':name}),flush=True)
 r=subprocess.run(cmd,cwd=w,env=dict(os.environ,QUEST_SYS_MPI_CASE=name))
 print(json.dumps({'ranks':ranks,'exit_code':r.returncode}),flush=True)
 r.check_returncode()
