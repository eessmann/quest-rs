import pathlib,subprocess,sys
base=pathlib.Path(__file__).resolve().parent
w=pathlib.Path('<worktree>')
for label in ['baseline','a','ab','abc']:
 source=base/('baseline' if label=='baseline' else 'snapshot-'+label)
 cmd=[sys.executable,str(base/'run_system_final.py'),'observer-build-'+label,str(w),sys.executable,str(w/'docs/verification/fixtures/qsp-optimization/run.py'),'build',label,str(source),str(base/'campaign')]
 subprocess.run(cmd,check=True)
