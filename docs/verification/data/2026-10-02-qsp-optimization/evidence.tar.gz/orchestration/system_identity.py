import os, subprocess, pathlib, json
commands = [
 ['uname','-a'], ['rustc','-Vv'], ['cargo','-V'], ['cargo','nextest','--version'],
 ['/usr/bin/cc','--version'], ['/usr/bin/clang','--version'], [os.environ['MPICC'],'-show'],
 ['mpiexec','--version'], ['ldd',os.environ['QUEST_ROOT']+'/lib64/libQuEST.so.4.3.0'],
 ['readelf','-d',os.environ['QUEST_ROOT']+'/lib64/libQuEST.so.4.3.0'],
 ['rpm','-q','hdf5-devel','mpich','gcc','clang'],
 ['lscpu','--json']]
for cmd in commands:
 print(json.dumps({'command':cmd}),flush=True)
 p=subprocess.run(cmd)
 print(json.dumps({'exit_code':p.returncode}),flush=True)
 if p.returncode: raise SystemExit(p.returncode)
print('Cargo target rustflags:', pathlib.Path(os.environ['HOME']+'/.cargo/config.toml').read_text())
