import json,pathlib,subprocess,sys,time
base=pathlib.Path(__file__).resolve().parent
w=pathlib.Path('<worktree>')
cmd=['ps','-C','cargo,rustc,cargo-nextest,cc1,cc1plus,clang,clang++,ninja,cmake,make,hydra_pmi_proxy','-o','pid,ppid,comm,etime,pcpu']
def idle(label):
 p=subprocess.run(cmd,text=True,capture_output=True)
 record={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'time':time.time()}
 (base/'campaign'/('processes-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 if len(p.stdout.strip().splitlines())>1 or p.returncode not in (0,1): raise SystemExit('Competing build/test process detected')
idle('before')
p=subprocess.run([sys.executable,str(w/'docs/verification/fixtures/qsp-optimization/run.py'),'run',str(base/'campaign'),'baseline','a','ab','abc'],cwd=w)
idle('after')
sys.exit(p.returncode)
