# Binding coverage portability repair

The system Linux and clean Nix generator checks failed because the installed
QuEST MPI/SUBCOMM package exposes `initCustomMpiCommQuESTEnv`, whereas the checked
main coverage inventory came from a non-MPI package. The coordinator's system
scratch render contained exactly that extra declaration; all 747 common entries
were identical. Its canonical communicator was `int` under MPICH, while another
MPI provider may use an opaque pointer.

The repair keeps `api_coverage.json` byte-identical and adds
`crates/quest-sys/generated/api_coverage_mpi.json`. Only the explicitly reviewed
header-conditional declaration is partitioned into that sidecar. The selected
native config must have both `QUEST_COMPILE_MPI=1` and `QUEST_COMPILE_SUBCOMM=1`
for sidecar emission/checking. Selection does not depend on seeing the API:
removal produces an empty sidecar and fails freshness. Renamed or newly added
APIs enter the main inventory until conditional requirements are reviewed, so
they also fail freshness. Observing this conditional API under disabled native
requirements is an error.

Sidecar rendering copies the parser's items and represents exact `MPI_Comm`
typedef fields with their logical public type. It then recomputes the overload
key. The parser's integer/opaque-pointer ABI information remains intact, and the
native compatibility probes remain unchanged. Non-MPI and MPI-without-SUBCOMM
packages skip sidecar checks without deleting or overwriting the checked sidecar.
The gated coverage reason now identifies the existing hand-written MPI bridge
and its Cargo/native capability requirements.

Changed scope: generator renderer, classification reason, one test-only root
fixture helper, MPI sidecar, and `crates/quest-sys/README.md`. Generated Rust/CXX,
`generated_adapters.json`, and the 747-entry main inventory have no diff. Main
SHA256: `13168b98dac9d9239069afb183aa212d49e53e9e375ccf5a8e303391660c3716`.
MPI sidecar SHA256:
`84beba3da1cc961dc7e32a2e390f6416ec749829975a4187256df85b5557cfa5`.

Evidence is retained under
`<artifacts>/receipts/`:

- `generator-red.log`: initial new test had a Rust matcher type error; corrected
  before behavioral red verification.
- `generator-red-behavior.log` and `generator-red-all.log`: the stable-inventory
  test and all three new regressions failed against the unchanged renderer.
- `generator-green-focused.log`: three conditional-coverage regressions pass.
- `generator-regenerate.log`: native MPI system regeneration succeeds.
- `generator-freshness.log`: `cargo run --locked -p xtask --
  generate-quest-bindings --check` succeeds against the real system package.
- `generator-tests-final.log`: `cargo test --locked -p xtask` passes all 41 unit
  and two integration tests, including real libclang extraction/classification.
- `generator-clippy.log`: initial strict lint exposed a new test helper's
  `map(...).unwrap_or_default()` style warning; the helper now fails explicitly
  when the expected main artifact is absent.
- `generator-clippy-final-fixtures.log`: `cargo clippy --locked -p xtask
  --all-targets -- -D warnings` succeeds after the final fixture strengthening.

The three self-contained regressions check a nonempty common inventory across
native feature configurations; rejection of signature changes, removals and
renames; ignoring a deliberately stale sidecar under non-MPI/no-SUBCOMM configs;
and identical sidecar bytes for integer and opaque-pointer MPI handles while
retaining both original ABI shapes. `git diff --check` and scoped rustfmt pass.

The coordinator owns clean Nix freshness and final workspace matrix validation.
This agent did not run native Darwin/non-MPI generation or MPI runtime tests;
the no-MPI portability claim here is the self-contained native-config fixture
plus unchanged checked common/source bytes. No commits or pushes were made.
