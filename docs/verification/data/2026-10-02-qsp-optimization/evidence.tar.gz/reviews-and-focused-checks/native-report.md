# Native build implementation report

Worktree: `<worktree>`.

## Scope and edits

- `devenv.nix`: one `pkgs.mpich` selection shared with QuEST; Linux absolute development-output `MPICC`; matching binary-output launcher first in shell `PATH`; existing serial HDF5; Linux all-feature build/nextest/doctests/ignored release QSP plus minimal example test entrypoint. Darwin keeps its prior minimal-example entrypoint.
- `nix/quest.nix`: Linux MPI+SUBCOMM and explicit MPI C/CXX wrappers; matching MPICH build input and package-owned installed MPI runtime path. CPU/OpenMP remains enabled; CUDA/HIP/cuQuantum remain disabled. Installed checks load the shared library independently, then run an installed CMake consumer with `initCustomQuESTEnv(0,0,0)` and cleared loader controls.
- README/CONTRIBUTING: system installed and clean Linux devenv all-feature recipes, wrapper/launcher consistency, serial HDF5 selection, full acceptance commands and Darwin limits.
- No Rust source edits, no commits, no timing runs, no full Cargo checks by this agent.

## Fresh verification

All successful commands used `devenv --no-tui -j 1 -u 2` (one derivation, two build cores).

| Check | Result | Evidence |
| --- | --- | --- |
| Linux `eval env outputs.quest.drvPath` | exit 0 | `native-nix-eval.log` |
| Linux `build outputs.quest` | exit 0 | `native-nix-build.log` |
| Installed CMake consumer and independent loader | exit 0 within successful derivation build | `native-quest-install-check.log` |
| Clean shell identities, HDF5 macros, ldd and readelf | exit 0; all dependencies found | `native-clean-shell.log` |
| Darwin `-s aarch64-darwin eval enterTest env outputs.quest.cmakeFlags outputs.quest.buildInputs` | exit 0; MPI OFF; LLVM OpenMP; no MPICC; minimal test only | `native-darwin-eval.log` |
| Linux `eval enterTest` | exit 0; all four requested acceptance commands plus minimal | `native-linux-test-eval.log` |
| `git diff --check` | exit 0 | executed after edits |

The independent loader is linked only to `${CMAKE_DL_LIBS}`, so MPI linked directly into the consumer cannot mask an incomplete QuEST RUNPATH.

## Exact clean Linux environment

- `QUEST_ROOT=/nix/store/331j44fm1cmrlglzm3lcji64j48c95pg-quest-4.3.0`
- `MPICC=/nix/store/4cacq188rg953wpcgbn0x52p3x1fn255-mpich-5.0.1-dev/bin/mpicc`
- `HDF5_DIR=/nix/store/2r3xag35722s4f2iwyiaap1svndqrayi-quest-serial-hdf5`
- `CC=/nix/store/z4c6k0mrlkwl3s4w9ysxc8vq1wylm3ms-gcc-wrapper-15.3.0/bin/cc`
- `CXX=/nix/store/z4c6k0mrlkwl3s4w9ysxc8vq1wylm3ms-gcc-wrapper-15.3.0/bin/c++`
- `CLANG=/nix/store/mn2y6cydn5phwf2hxgfc3n7zjf48d5xg-clang-wrapper-21.1.8/bin/clang`
- `LIBCLANG_PATH=/nix/store/a3kjvvlm7f8abcmxh6f8dndiwc4vp726-clang-21.1.8-lib/lib`
- QuEST derivation: `/nix/store/fcdisj85swhp0mb0ihcnk79w6m6ssdcj-quest-4.3.0.drv`.
- MPI launcher: `/nix/store/bddrlz6zj0gwrx4rablh2qhvq5jg403y-mpich-5.0.1-bin/bin/mpiexec`.
- MPI shared libraries: `/nix/store/ni3588mg6zx24dnv4yjmbhb44nh08iwv-mpich-5.0.1/lib`.
- Rust Cargo: `/nix/store/7jyzh8sbm1h140bdya4kvi01hndnzfac-rust-default-1.100.0-nightly-2026-09-23/bin/cargo`.
- Rust `1.100.0-nightly`, commit `6bb1652a020e80cef79332741d89e996d71933c9`, commit date 2026-09-22, x86_64-unknown-linux-gnu, LLVM 23.1.1.
- Serial HDF5 1.14.6: `/* #undef H5_HAVE_PARALLEL */`.
- MPICH 5.0.1; GCC wrapper 15.3.0; libclang 21.1.8.
- Shell stdenv hooks expose `CC=gcc` and `CXX=g++`, resolving to the selected GCC wrapper on `PATH`; evaluated environment attributes above contain absolute paths.

Use an explicit CLI separator for scripted commands:

```sh
devenv --no-tui -j 1 -u 2 shell --clean -- bash -c 'CARGO_BUILD_JOBS=2 cargo build --workspace --all-features --locked'
```

Main agent owns full Cargo acceptance and actual two-/four-rank MPI tests. Use an independent Cargo target directory to distinguish system and clean Nix artifacts.

## Errors found and resolved

1. Sandboxed initial devenv evaluation failed: `Failed to create /run/user/<uid>/devenv-f9c8a4f: Read-only file system (os error 30)`. Evaluation/build/shell succeeded with approved escalation. A direct sandboxed `nix derivation show` also cannot connect to the daemon socket (`Operation not permitted`); this was a diagnostic access limitation.
2. Initial MPI-enabled QuEST output `/nix/store/g71sgvyfsl3c82svj0dghryya2glad5x-quest-4.3.0` built and passed the directly linked installed consumer but `ldd` with loader variables clear reported `libmpicxx.so.12 => not found` and `libmpi.so.12 => not found`. RUNPATH omitted MPICH despite `CMAKE_INSTALL_RPATH_USE_LINK_PATH=ON`. Added Linux package-owned `CMAKE_INSTALL_RPATH=${lib.getLib mpi}/lib` and independent dlopen check. Final output resolves both libraries from the matching MPICH output; native runtime path includes that directory plus `$ORIGIN/` and native compiler runtime paths.
3. A scripted shell command without `--` exited 0 but never ran the requested bash body because devenv interpreted `-c` itself. Explicit `shell --clean -- bash -c` executes the body and produced the final verified shell evidence.

## Limits

- Darwin was evaluated, not built or executed.
- All-feature Rust tests, doctests, Clippy, binding freshness, minimal Rust example, and real multi-rank MPI validation remain with the main agent. This report does not claim they pass.
- Source lock remains unchanged.

## Immutable baseline follow-up verification

Against `<artifacts>/baseline/Cargo.toml` in clean devenv, with separate `<artifacts>/devenv-target` and `CARGO_BUILD_JOBS=2`:

- `cargo build --manifest-path ... --workspace --all-features --locked`: exit 0. Native ABI witness confirms selected MPICC matches QuEST loaded MPI library.
- `NEXTEST_TEST_THREADS=4 OMP_NUM_THREADS=2 cargo nextest run --manifest-path ... --workspace --all-features`: exit 0; 1091 tests across 166 binaries, 1091 passed (2 slow compile-fail harnesses), 3 skipped. Actual MPI two/four-rank distributed application and low-level subprocess tests passed.
- Full stdout/stderr, exact command, exit and elapsed JSON receipts: `target/qsp-optimization/receipts/baseline-devenv-build.{log,command,exit,json}` and `baseline-devenv-nextest.{log,command,exit,json}` in the parent repository. Build elapsed is derived from command/exit receipt timestamps; nextest elapsed uses monotonic orchestration timing. These are build/test durations, not benchmark results.
- Existing baseline warning: `feature(generic_const_exprs)` unsupported with next-generation trait solver in `quest-polynomial/src/lib.rs:1`; compiler falls back for that crate. Strict Clippy acceptance needs separate investigation.
- Baseline source was not edited. This manifest-path run does not replace final exact worktree acceptance.

Tool provenance from `baseline-devenv-tool-identities.log`: pinned Nix Cargo `1.100.0-nightly (495c385d0 2026-09-16)`. Shell `command -v cargo-nextest` returns `/nix/store/apyihjqs3lmxqrhrvd4xny1581g6m2cw-cargo-nextest-0.9.144/bin/cargo-nextest`, but Cargo subcommand discovery invokes `<home>/.cargo/bin/cargo-nextest` version `0.9.143`, commit `60fa45f638ffc3f35e74afa65737f45fcd32db2a` (2026-08-04). The latter is the actual tested nextest launcher; compilation used the pinned Nix Rust toolchain.

## Current-worktree independent native verification

- `cargo run --locked -p xtask -- generate-quest-bindings --check` in clean devenv: exit 1; `crates/quest-sys/generated/api_coverage.json is stale; rerun xtask generate-quest-bindings`. Matches the parent system-lane failure. Full `final-devenv-bindings.{log,command,exit,json}` receipts retained; generated files not changed by this agent. Parent is diagnosing regeneration differences in scratch.
- `cargo run --locked -p xtask -- check-native-consumers --backends cpu,omp --work-dir <artifacts>/devenv-consumers`: exit 0. Direct CPU and OpenMP statevector/density tests; facade, wrapped and renamed CPU/OpenMP consumers; all four RUNPATH and complete native closure checks passed. Existing helper clears all LD_/DYLD_ overrides before build, loader inspection and execution.
- Consumer fixture and full per-case evidence preserved at parent `target/qsp-optimization/devenv-consumers`; outer receipts `final-devenv-consumers.{log,command,exit,json}`. Both runs use independent devenv-target, two Cargo jobs and OMP_NUM_THREADS=2.

## Final clean Nix acceptance and idle handoff

All final commands ran at the actual worktree root without `--manifest-path`, in clean devenv with two Cargo jobs, four nextest threads and two OpenMP threads. Fresh target `<artifacts>/devenv-acceptance-target` was never used for immutable baseline source.

- Final `clippy`: exit 0, source changes `[]`, receipt `acceptance3-devenv-clippy.*`.
- Final `build`: exit 0, source changes `[]`, receipt `acceptance3-devenv-build.*`.
- Final `nextest`: exit 0, source changes `[]`, receipt `acceptance3-devenv-nextest.*`.
- Final `doctest`: exit 0, source changes `[]`, receipt `acceptance3-devenv-doctest.*`.
- Final nextest: 1120 tests across 167 binaries, 1120 passed, 3 skipped; final execution summary 62.453s.
- Final doctests: 65 passed, 0 failed, 1 ignored across 22 result groups.
- Ignored release QSP: `acceptance2-devenv-ignored-release.*`, exit 0, 3 passed (2 slow), 118 ordinary tests skipped by ignored-only selection. Degree 8192 interval certification; degree 8105 offline export/certification; degree 8105 parallel canonical/generalized bit preservation. QSP sources unchanged by subsequent lint-only fixes, so release evidence remains valid.
- Fresh binding check `acceptance2-devenv-bindings.*` exit 0; earlier repaired check and all 43 xtask tests also pass. Later source fixes only reorder a CLI struct literal field and relocate an unchanged 1402-byte test module; native/generator source remained unchanged.
- Explicit MPI registered binary metadata: `acceptance-devenv-mpi-list.raw.json`; absolute matched launcher with `-l -n 2/4`, exact inner cases selected through QUEST_SYS_MPI_CASE. Both exit 0; per-rank logs each contain exactly one passed test result on all 2 or all 4 ranks. Cases: `mpi_collective_preflight_rejects_mismatch_on_every_rank` and `mpi_subgroups_and_excluded_ranks_preserve_contexts`. Native compiled MPI/SUBCOMM both enabled; the four-rank body asserts world size 4. All launcher/registry/per-rank commands and exits retained in receipts.
- CPU/OpenMP installed consumers and their complete runtime closure checks remain passed, with loader overrides cleared.
- Generated devenv test script starts with `set -euo pipefail`; upstream source and exact generated script retained in `devenv-test-errexit-evidence.md` and `devenv-test-script.sh`. Full `devenv test` was not rerun.
- Pinned compiler emits trait-solver fallback notices for `generic_const_exprs` even under successful strict Clippy. Report the strict command success, not an absence of compiler operational notices.

Preserved failed evidence: stale `api_coverage.json` freshness before generator repair; shared baseline/worktree artifact unresolved SharedConvolutionWorkspace (`acceptance-devenv-build.*` plus stale numerical artifact metadata); strict Clippy items-after-test-module (`acceptance2-devenv-clippy.*`). No Rust source was modified by this native agent. Parent coordinated minimal repairs without suppressions. Final source identity/patch: `acceptance3-devenv-source.{json,patch}`; all final per-command source checks unchanged.

All assigned builds/tests have exited. No timing campaign was run by this agent. Main agent can begin the uncontended timing campaign after this idle handoff.

Final formatting gate after completed official timing campaign: clean devenv `cargo fmt --all -- --check` passed exit 0. Full `acceptance3-devenv-fmt.{command,log,exit,json}` receipt saved; all recorded final source hashes unchanged (`source_changes_during_validation=[]`). No build or test was rerun. Agent idle again.
