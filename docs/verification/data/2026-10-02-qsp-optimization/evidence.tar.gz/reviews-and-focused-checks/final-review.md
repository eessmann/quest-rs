# Independent final production review

Reviewed 2026-10-02 against baseline `d19de2a0fd605b46bbc57e87fee36ba811a7d2b2` and `docs/superpowers/plans/2026-10-02-all-features-qsp.md`. Scope includes the complete tracked production diff and untracked shared-convolution implementation, shared tests, and MPI coverage manifest. Read the earlier Native/A/shared and B/portable-Send reviews and current task reports. Fixture edits were still in progress and are explicitly deferred below.

## Findings

No actionable production correctness or scope findings.

## Source checks

- Algorithm-specific completion remains opaque outside the crate, exposes the optional RHW ratio and selected algorithm, and dispatches synthesis by retained payload. NLFT skips ratio samples/extraction/retention. Four versus five transform charging, cumulative retries/residual charging, and algorithm-dependent memory reservation are consistent in the binary64 and offline paths.
- The binary64 shared workspace preserves ordinary convolution's support checks, padding, backend, left/right operand order, finite checks, inverse normalization, and optional Rayon threshold/scratch behavior. Readiness is scoped to immutable RHS borrows, reset on new sessions and after errors. Three data arrays, FFT scratch, optional second scratch, planner estimate, cold/warm work and retained plan sizes are accounted for.
- Both C integrations use the required RHS schedule `[0,1,1,0]`. All products finish before midpoint/reconstruction arithmetic. Compact windows preserve the original offsets, out-of-support zeros, shift by one in reconstruction, and per-index a-then-b or xi-then-eta operation/failure order. Selected window vectors become the output vectors in place; the other windows and session disappear before recursive descent, and midpoint storage is dropped before reconstruction.
- The binary64 group maximum produces exactly the previous per-product FFT size because each group has equal left supports and equal right supports. Offline retains its distinct `support.next_power_of_two()` rule, zero shortcut and support<=16 direct loop. Offline spectrum readiness includes FFT length; transform/twiddle/direct work keeps its original precision-limb weighting. Its group-local spectra and compact payload fit the existing separate conservative grid and recursive storage envelopes; this is modeled memory, not a process-wide allocation quota.
- The root alone omits transfer reconstruction. Both children still produce transfers, and the singleton root retains pivot/reflection validation while omitting unused normalization. The independent ordinary-convolution recursion checks both reflections and full transfer output; work formulas separately account for B and C savings. New pointer/capacity tests substantiate window reuse.
- The generator partitions only the explicit reviewed conditional declaration, requires native MPI and SUBCOMM to check the sidecar, emits an empty sidecar when the declaration disappears, and leaves renamed/new declarations in the common inventory. Logical `MPI_Comm` normalization changes cloned coverage entries only; parsed ABI evidence and native compatibility probes remain intact. No generated Rust/CXX bridge or common manifest change is hidden by this repair.
- Linux Nix passes the same MPICH package to QuEST's imported MPI targets, `MPICC`, and launcher selection. The explicit installed MPI RUNPATH and independent dlopen consumer cover the previously masked indirect-library dependency. Installed execution uses CPU-only initialization. Existing native build probes compare the wrapper's ABI/loaded-library identity to QuEST; actual two/four-rank evidence still must come from the coordinator's acceptance runs. Darwin retains MPI-off/OpenMP feature selection and the minimal test entrypoint; its common installed-consumer checks changed but were not executed on Darwin.
- The portable negative-Send assertion targets the same public type as the deleted diagnostic snapshot; the remaining compile-fail glob is preserved. Read the retained positive/negative control evidence rather than treating absence of a diagnostic file as weakened coverage.

## Fresh checks and source identity

`git diff --check` passed. No builds, tests, benchmark trials, production edits, commits or pushes were performed in this review, avoiding interference with the coordinator's two environment acceptance runs. Focused test claims rely on the retained logs listed in the task reports, including final `inverse-c-reuse-*` logs rather than superseded initial C logs.

The three frozen C sources match the implementation report's SHA-256 values:

- `crates/quest-qsp/src/kernel.rs`: `108016649f028d436c9a8c384a9fb96793ea0c623fcfec8061e4b4ee6561c3a1`
- `crates/quest-qsp/src/offline/kernels.rs`: `5edde0ea61ad1a3712121343aaf12df5603c85b045a557a17cc756430a728b5d`
- `crates/quest-qsp/src/offline/fft.rs`: `5bcb3b6c43310fdfed01faf0fa8c196b876aaa82ec1793a0367038e437665e10`

## Outstanding evidence and material limits

- The coordinator is running final full all-feature system and clean devenv acceptance in separate target directories. This review does not substitute focused tests or older baseline receipts for those runs, native ABI identities, installed-consumer checks, or explicit two/four-rank runtime tests.
- The measurement fixture is being revised by its owner. This review does not close the two fixture findings in `review-b-fixture.md`; source/build identity validation and process-group timeout cleanup require their final source check. The new stage memory counters also require review after freeze.
- No completed immutable baseline/A/A+B/A+B+C interleaved measurement campaign was reviewed. Runtime, allocation, peak-memory and exact cross-variant correctness claims remain unverified here. No speedup claim is made.
- Darwin runtime, other architectures, unavailable SIMD backends, and larger distributed machines were not exercised by this review.

## Frozen fixture and staged-patch follow-up

Reviewed the frozen `run.py`, `main.rs`, `allocator.rs`, allocator probe, controller regressions and fixture documentation after the coordinator confirmed freeze. No actionable findings. Both P2 findings from `review-b-fixture.md` are resolved:

- Timeout/interruption cleanup escalates against the process group even when the `/usr/bin/time` leader has exited. The regression deliberately leaves a TERM-ignoring child and verifies it is dead after cleanup.
- Each variant uses a newly created, independent Cargo target directory. The post-build identity includes the instrumented source, observer package and resolved lockfile, and copied executable. Before any trial, all variants are compared against that saved identity plus the original source/binary receipts; the final comparison repeats these checks. Tests cover pretrial source/package/binary tampering and mutation during trials. Applicable Cargo config and toolchain evidence are recorded from the actual copied-source build directory.

Each trial must contain exactly the six requested successful workloads. Missing/duplicate/error rows, malformed fingerprints/grids, and cross-variant or cross-trial fingerprint/grid differences invalidate completion independently of process exit and source-identity gates. Raw trial receipts remain separate and existing receipts cannot be overwritten. No completed campaign is inferred from these controller tests.

The offline completion hook brackets the existing completion call without changing its arguments, result, or numerical operations. Its RAII phase guard closes on errors as well as success. Nested phase counters use their own live baseline, allocation baseline, and peak; they do not reset the enclosing sample. The binary64 hooks observe existing cumulative completion, inverse, and response-reconstruction charges; the formerly temporary response workspace is still dropped before the residual loop. The documented stage boundaries, per-iteration work versus summed timing/allocation counts, modeled-memory exclusions, and baseline completion undercharge caveat are accurate. Allocator instrumentation overhead remains part of the observed timings, so results are observations of the instrumented scalar fixture rather than an uninstrumented application guarantee.

Fresh lightweight checks, all exit 0:

- `python3 -m unittest discover -s docs/verification/fixtures/qsp-optimization -p test_run.py`: six controller tests pass, including the process-group child probe.
- `rustc --edition=2024 docs/verification/fixtures/qsp-optimization/allocator_probe.rs -o /tmp/qsp-final-review-allocation-probe`, followed by that executable: nested allocation counts and inner/outer peaks pass.
- Independently checked all three patch SHA-256 values from `docs/verification/data/2026-10-02-qsp-optimization/snapshots/manifest.json`, archived baseline `d19de2a0fd605b46bbc57e87fee36ba811a7d2b2` into fresh temporary directories, and applied each patch independently. The reconstructed `.rs`/`.toml`/`.lock` inventories match `snapshot-a` (480 files), `snapshot-ab` (480), and `snapshot-abc` (482). Every A+B+C changed file also matches the currently reviewed worktree byte-for-byte. Temporary reconstruction directories were removed automatically.

The coordinator reports fresh full builds passed in both environments, with suites ongoing; that is coordinator-provided status, not independently rerun evidence. Real campaign trials have not yet been reviewed. The separate `summarize.py` and its tests were still being added and are outside this frozen controller assessment.

## Frozen summarizer follow-up

Reviewed the subsequently frozen `summarize.py`, `test_summarize.py`, and updated fixture README. No actionable findings. Summary generation requires the three successful controller gates, four exact variant labels, three trials, and 72 validated records. It independently reads all twelve trial exit receipts, requires the six unique successful workloads per trial, rechecks cross-variant/trial fingerprints and grids, and rejects nonfinite/negative measured fields and invalid iteration counts before writing derived outputs.

Normalization is correct for the fixture: binary64 completion and outer timing/allocation totals are divided by iteration count; offline's single measured completion remains undivided; live-memory peaks and per-solve charged work are never divided. Median/min/max are computed across the three normalized trials. Markdown units and backend stage distinctions agree with the fixture. Input receipt hashes are recorded and raw receipts are read-only. The summarizer relies on the controller's saved source-identity gate rather than claiming to rerun build provenance verification itself.

Fresh `python3 -m unittest discover -s docs/verification/fixtures/qsp-optimization -p test_summarize.py`: two tests passed, covering normalization and rejection cases. Fresh `git diff --check` also passed. No campaign execution or performance result was reviewed in this follow-up.

## Final Clippy field-order fix

Reviewed the additional diff in `crates/quest-qsvt-cli/src/distributed/wire.rs:241`. It moves only the `verification_tolerance` shorthand field below `workflow` and `route` in the returned `FrozenInput` literal. All three are existing, already evaluated local variables. No decoding reads, validation, fallible expressions, values, or wire layout changed. No actionable findings; fresh `git diff --check` passed. Full post-fix acceptance remains with the coordinator; no additional tests were launched for this style-only reorder.

## Final test-module relocation and production-review closure

Independently compared `crates/quest-language/src/quantum/program.rs` against the baseline. The existing `#[cfg(test)] mod plan_order_tests` is relocated to EOF with its separator blank line. The module's 1402 bytes are identical, SHA-256 `0d970f8a15cc04acda5dbef9299ff4448fc5631b2327762573f5f97a8ac4536c`; removing that module and its separator from both files leaves byte-identical content. Thus no production code or test behavior changes. Fresh diff whitespace check passed.

Production source review is closed with no actionable findings, including both final lint-only adjustments. Final post-adjustment environment acceptance and the measurement campaign remain separate coordinator-owned evidence; their reported progress is not a substitute for reviewing completed receipts.

## Completed official campaign evidence review

Reviewed the official campaign under `<artifacts>/campaign` and its outer `receipts/official-campaign.{json,log}`. No actionable findings. The official command exited 0 after approximately 165.5 seconds (20:06:05–20:08:51 UTC on 2026-10-02). All three completion gates are true, with 72 successful workload records and no recorded errors.

Independently reran the reviewed summary calculation in memory: its result exactly matches `summary.json`, and rendering exactly matches `results.md`. This rereads all twelve exit receipts and 72 rows, verifies the six workloads each time, and checks matching export fingerprints and accepted grids across all variants/trials. Every time(1) stderr also records exit status 0. Iteration counts match the real fixture (binary64 degree256:12; degree1024:4; offline:1).

Revalidated every variant's current source/package/executable against its saved build identities. Its original source inventory also matches the corresponding previously reconstructed immutable stage snapshot. Independently checked the recorded toolchain, resolved Cargo.lock, observer, allocator, driver and Cargo config identities against `comparison-config.json`; all match across variants. Each independent build completed successfully before the timing interval.

The before/after process snapshots contain no matching compiler/build/test/MPI launcher process. A scan of all retained outer receipts found no build/test receipt overlapping the official campaign interval; only the campaign receipt itself overlaps. This supports the coordinator's no-competing-build execution record. These endpoint process snapshots are not continuous monitoring of every possible unrelated host process, and no stronger system-isolation claim is warranted.

The measurements support the following ordered interpretation:

- Baseline to A: binary64 completion median falls 23.13% at degree256 and 8.91% at degree1024, with allocation counts 39→37 and lower completion live peaks. Offline completion medians fall 12.63–19.10%, with lower allocation counts, completion peaks and charged work. Baseline binary64 completion's unchanged reported work is the documented correction of its missing FFT charge, not evidence that ratio work was retained.
- A to A+B: binary64 end-to-end medians fall 3.97% and 6.94%; allocation/work counts fall in both backends. Offline timing is not uniformly improved: three of four end-to-end medians rise slightly. Completion code/resources are unchanged at this stage, so its timing variation cannot be attributed to B.
- A+B to A+B+C: binary64 end-to-end medians fall 9.98% and 3.76%, with further allocation/work reductions and lower end-to-end live peaks. Offline allocation/work counts fall, but degree16/256-bit end-to-end median rises approximately 0.50%; other offline timing changes are small. Completion resources remain identical to A, and completion timing differences between A/AB/ABC are ordinary measurement variation rather than a C optimization.
- Full A+B+C versus baseline: observed binary64 end-to-end medians are 19.22% and 17.02% lower. Offline medians are 7.94%, 5.06%, 3.31%, and 2.43% lower for degree16/128-bit, degree16/256-bit, degree256/128-bit, and degree256/256-bit respectively. Offline end-to-end peak additional live bytes are exactly unchanged across variants for each workload, although completion peaks are lower.

Three instrumented trials on one host establish these observed medians/ranges, not statistical significance, a universal speedup, monotonic stage improvements, or the cause of a historical Dashu regression. Intermediate trial ranges overlap, and byte-identical completion stages themselves display timing variation. The draft main report's method and caveats are consistent with this interpretation; its measured table had not yet been inserted at review time.

Also read the final `acceptance4-system-*` and `acceptance3-devenv-*` command receipts: full workspace all-feature build, nextest, doctests, formatting and strict all-target/all-feature Clippy all exit 0 in their respective lanes; the system binding freshness receipt exits 0. This follow-up did not rerun those commands or independently recalculate every suite count. It modified only this review report, leaving raw campaign data and the main report untouched.
