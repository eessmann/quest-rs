# Shared FFT numerics implementation

Implemented only the shared numerics task in `<worktree>`. No commits or QSP edits were made by this task. The approved plan is `docs/superpowers/plans/2026-10-02-all-features-qsp.md`.

## API and accounting

`quest_numerics` exports `SharedConvolutionWorkspace` and `SharedConvolutionSession`. Constructors are `new(max_left, max_right, backend, limits)` and `new_with_policy(..., execution)`. They retain exactly three L-length arrays plus the same FFT plans/scratch model as ordinary convolution, with additional parallel forward scratch admitted under the existing threshold (L >= 2048 and more than one caller-pool worker). No pool borrow is stored in the workspace.

`workspace.session([right0, right1], execution)` returns a session without allocation or eager validation. Its separate workspace, RHS, and pool lifetimes prevent output/input/pool borrows from escaping their scopes. `session.work_for(index)` returns the next product's checked modeled work; `session.product(left, index)` returns the reusable borrowed output. Only indices 0 and 1 are accepted.

For T = 8*L*max(log2(L),1), cold work is 3*T+L and warm work is 2*T+L. Constructor `resource_usage().work_units` is a per-product cold upper bound, never a whole-session charge. Call `work_for` before each product when charging a multi-product schedule. A successful [0,1,1,0] schedule charges 10*T+4*L rather than 12*T+4*L.

Each new session resets both readiness flags. RHS transforms are lazy. Cold products preserve independent forward-pair parallelism; warm products transform only the left input. A failed product resets both readiness flags. The next product clears left padding and, whenever its RHS is cold, clears that RHS's padding and rebuilds its spectrum. An error in an unused RHS is not observed until that index is selected.

Selected input shapes are checked before finite scans. Left finite scans precede right finite scans; cold forward-output scans retain left-before-right order; multiplication retains left*right order. Inverse input/output finite checks and normalization use the existing FFT workspace implementation. Support and fixed padding are identical to an ordinary workspace with the same maximum supports, including `new(size,size)` use in cached QSP kernels. Existing `ConvolutionWorkspace` implementation and allocation footprint are untouched.

## Tests and retained verification

All Cargo commands used:

```text
cwd=<worktree>
CARGO_TARGET_DIR=<artifacts>/focused
CARGO_BUILD_JOBS=2
```

Test-first run of `cargo test -p quest-numerics --test shared_convolution --all-features --locked` failed with exit 101 because the public shared workspace API was absent. During implementation, one googletest reference-matcher compile error was corrected; strict Clippy initially identified doc-markdown and missing-const issues, both corrected without lint suppression. These are implementation-time failures, not omitted suite regressions.

Final verified commands:

| Command | Exit | Evidence |
| --- | --- | --- |
| `cargo test -p quest-numerics --all-features --locked` | 0 | 82 integration tests and 4 doctests; `shared-all-features-test.log` |
| `cargo test -p quest-numerics --no-default-features --locked` | 0 | 75 integration tests and 4 doctests; `shared-no-default-test.log` |
| `cargo clippy -p quest-numerics --all-features --all-targets --locked -- -D warnings` | 0 | Tool output confirms completion |
| `cargo clippy -p quest-numerics --no-default-features --all-targets --locked -- -D warnings` | 0 | Tool output confirms completion |
| `rustfmt --edition 2024 --check --config skip_children=true crates/quest-numerics/src/lib.rs crates/quest-numerics/src/fft.rs crates/quest-numerics/src/fft/shared.rs crates/quest-numerics/tests/shared_convolution.rs` | 0 | Scoped formatting only |
| `git diff --check` | 0 | No whitespace errors |

The 10 all-feature shared tests cover exact same-backend [0,1,1,0] products, fixed support/padding, shorter inputs and new sessions, stable output storage, lazy work accounting, index rejection, readiness invalidation and recovery after failed products, shape-before-finite and left-before-right errors, sequential and 1/2/4-worker pools, optional available SIMD, exact byte/work/length admission, and singleton T accounting. The no-feature configuration additionally checks unavailable SIMD rejection (7 shared tests total). SIMD tests conditionally return on `BackendUnavailable` as existing FFT tests do.

Full workspace, native dependency, MPI, release correctness, and benchmark evidence remain the parent task's responsibility. This task makes no performance or whole-workspace validation claim.
