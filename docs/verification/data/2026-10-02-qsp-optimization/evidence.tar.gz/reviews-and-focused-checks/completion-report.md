# Task A: algorithm-specific completion

Implemented against baseline `d19de2a0fd605b46bbc57e87fee36ba811a7d2b2` in `target/worktrees/all-features-qsp`. No inverse-root or shared-convolution integration changes were made by this task. No commits or pushes.

## Behavior

- Existing `complete` and `complete_with` select `Policy.algorithm`.
- Private `CompletionPayload<M>` has `InverseNlft` and `Rhw(WeissRatio<M>)` variants. `CompletedPolynomial::algorithm()` is const and derives its answer from this tag; `weiss_ratio()` returns `Option<&WeissRatio<M>>`.
- Both synthesis conventions dispatch using the retained payload tag. Inverse NLFT cannot enter Half-Cholesky without an RHW ratio.
- Internal binary64 and offline completion return the same explicit tagged `CompletionData<C>`; no empty ratio placeholders.
- NLFT omits the sample clone, negative-exponent ratio evaluation, fifth transform, and retained ratio. The four common transforms and common scalar arithmetic retain their original ordering. RHW ratio computation retains its original order before outer-complement exponentiation.
- Binary64 charges four FFTs for NLFT and five for RHW, at eight units per FFT point per stage. The old `*32` already accounted for four transforms; RHW was undercharged. Residual work and every refined attempt remain cumulative. Offline transforms retain their existing 32-unit, precision-weighted charges and automatically omit the selected transform.
- Binary64 completion storage removes one grid vector and one coefficient vector from NLFT's conservative allowance; synthesis explicitly reserves an RHW ratio when present. Offline preserves its conservative common recursive/FFT allowance and adds the selected RHW sample/coefficient payload explicitly, in scalar units.
- Migrated the existing RHW ratio caller and crate documentation.

## Regression evidence

Tests were added before implementation. On original code:

- `completion_charges_four_nlft_transforms_and_five_rhw_transforms` failed because RHW admitted one unit below its true five-transform budget.
- `completion_refinement_charges_all_attempts_and_residuals` failed for the same RHW undercharge across refined attempts.
- `nlft_completion_skips_the_ratio_transform_at_each_precision` failed with actual RHW-minus-NLFT work zero, versus expected 10240/20480 at 128/256 bits.
- API regression initially failed to compile because the new const algorithm accessor and optional ratio did not exist.
- `offline_memory_admits_only_the_selected_completion_payload` failed before storage accounting was changed because RHW admitted the NLFT-only storage limit.

Final regressions verify default/explicit NLFT `None`, RHW `Some`, target-offset/gauge/grid/contractivity provenance, exact binary64 complement and residual bits across algorithms, selected synthesis identity, exact one-unit work boundaries, cumulative grid refinement and residual work, offline common complementary values, precision weighting at 128/256 bits, and explicit storage admission. Existing independent RHW certification and both-convention/algorithm tests also pass.

## Verification

Toolchain: `rustc 1.101.0-nightly (c36f14571 2026-10-01)`, `cargo 1.101.0-nightly (f3865b2a4 2026-09-29)`.

All cargo commands used:

```sh
CARGO_TARGET_DIR=<artifacts>/focused
CARGO_BUILD_JOBS=2
```

Commands and results:

- `cargo test -p quest-qsp --features offline-synthesis --test completion_outer --lib --locked`: exit 0, 30 unit tests passed / 1 ignored and 4 completion tests passed at that point; later storage/refinement tests are included in final all-feature run.
- `cargo test -p quest-qsp --all-features --locked`: final exit 0, 109 unit/integration tests passed, 3 existing scale tests ignored, 8 doctests passed. Full final output: `completion-tests.log`.
- `cargo test -p quest-qsp --locked`: exit 0, 29 unit/integration tests and 5 doctests passed, none ignored.
- `cargo clippy -p quest-qsp --all-features --all-targets --locked -- -D warnings`: final exit 0. Full output: `completion-clippy.log`. Earlier Clippy failures identified visibility, checked arithmetic, test fixture arithmetic and missing test semicolons; all were corrected. Production multiplication is checked; bounded independent test formulas have documented lint allowances.
- `rustfmt --check --edition 2024` on all six modified Rust files: exit 0.
- `git diff --check`: exit 0.

The existing quest-polynomial nightly trait-solver warning appears in these runs; Clippy still exits 0. Ignored scale tests, full workspace/native/MPI/devenv checks and benchmark evidence remain assigned to the parent task. No speedup claim is made here.

Files owned by A: `crates/quest-qsp/src/kernel.rs`, `src/stages.rs`, `src/offline/kernels.rs`, `src/offline/mod.rs`, `tests/completion_outer.rs`, `tests/rhw.rs`, and `README.md` within the qsp crate. Other worktree edits belong to concurrent tasks.
