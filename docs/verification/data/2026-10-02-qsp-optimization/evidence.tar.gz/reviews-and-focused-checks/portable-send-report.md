# Portable PreparedProgram !Send assertion

## Cause

The baseline system all-features nextest run failed only the snapshot for
`structured_preparation_is_not_send`. The semantic E0277 diagnostic was unchanged;
rustc 1.100 rendered the standard library `Vec` declaration on one line, while
rustc 1.101 rendered its opening as `pub struct Vec<`. See baseline receipt
`target/qsp-optimization/receipts/baseline-system-nextest.log`, lines 1640-1756.

The installed trybuild 1.0.121 API has `pass` and `compile_fail`, with no custom
normalization hook. Its existing normalization leaves this source excerpt intact.

## Change

Moved the structured preparation Send contract into a dedicated compile-time
assertion in `crates/quest/tests/compile_fail.rs`, removing its old UI source and
stderr snapshot. A local `AmbiguousIfSend<A>` trait has a blanket implementation
for `A=()` and a second implementation for `A=ImplementsSend` only when `T: Send`.
For a non-Send type, the compiler infers the single applicable implementation.
If `PreparedProgram` becomes Send, the placeholder is ambiguous and compilation
fails. This proves the same negative trait contract without comparing diagnostic
wording. The assertion uses the concrete public `PreparedProgram<'static>` type,
and introduces no dependency or production changes.

The seven other UI compile-fail fixtures and their existing snapshots remain
unchanged, and still run through the existing glob.

## Evidence

- System compiler: `rustc 1.101.0-nightly (c36f14571 2026-10-01)`.
- Pinned Nix compiler: `rustc 1.100.0-nightly (6bb1652a0 2026-09-22)`.
- Both compilers accept the actual assertion and reject the identical assertion
  after replacing only `quest::PreparedProgram<'static>` with the Send type `u64`.
  Negative controls fail with E0283 and explicitly report both trait impls.
  Exact copied sources and command/result receipts are retained under
  `target/qsp-optimization/receipts/portable-send-assertion-{actual,control}.rs`
  and `portable-send-exact-{actual,control}-{system,nix}.{json,log}`.
  The Nix direct positive control uses unchanged baseline PreparedProgram metadata;
  the system direct positive control uses the current worktree build metadata.
- Current system worktree focused command:
  `python3 target/qsp-optimization/run_system.py portable-send-system-nextest <worktree> cargo nextest run -p quest-rs --all-features --test compile_fail`
  passed both tests (2 passed, 0 skipped; all seven UI fixtures checked).
  Receipt: `portable-send-system-nextest.{json,log}`. Native QuEST/MPI provenance
  warnings and the existing quest-polynomial trait-solver warning were emitted.
- `rustfmt --check crates/quest/tests/compile_fail.rs` and scoped `git diff --check`
  both passed.

The first focused Nix shell attempt was blocked by the sandbox's access to the
local Nix daemon socket before tests ran (`portable-send-nix-nextest.{json,log}`).
The approved retry passed both tests against the current worktree (2 passed,
0 skipped; seven remaining UI fixtures checked), with the pinned Nix QuEST/MPI
install and rustc 1.100. Receipt: `portable-send-nix-nextest-approved.{json,log}`.
Command: `devenv --no-tui -j 1 -u 2 shell --clean -- bash -c
'CARGO_TARGET_DIR=<artifacts>/devenv-target
CARGO_BUILD_JOBS=2 NEXTEST_TEST_THREADS=4 OMP_NUM_THREADS=2 cargo nextest run -p
quest-rs --all-features --test compile_fail'` (the quoted shell command is a single
line in the receipt).

Full workspace verification remains coordinated by the parent task. No commits
or pushes were made.
