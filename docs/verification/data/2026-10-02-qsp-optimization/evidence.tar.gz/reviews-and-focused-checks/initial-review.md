# Initial independent review: Native, A, shared numerics

Reviewed 2026-10-02 against baseline `d19de2a0fd605b46bbc57e87fee36ba811a7d2b2`, using the approved plan and native/completion/shared task reports. Reviewed tracked changes in those scopes plus the untracked `fft/shared.rs` and `tests/shared_convolution.rs`. Benchmark fixtures, B, and C integration are outside this review. At the final source check, the kernel diff still contained completion changes only; no inverse-root change was included in this review.

## Findings

No actionable correctness or scope findings in the reviewed changes.

## Checks performed

- Compared shared convolution against ordinary convolution: same support and fixed padding, selected-input shape checks before finite checks, left-before-right finite scans, forward-pair error ordering, left-times-right multiplication, inverse normalization, and cold/warm execution paths. Session borrows prevent mutable RHS aliasing; readiness resets at session creation and after product failure. A cached successful RHS spectrum cannot become stale within a session.
- Checked shared admission arithmetic: three data arrays, original FFT scratch/planner model, optional second scratch, checked cold `3*T+L` and warm `2*T+L` work. Ordinary `ConvolutionWorkspace` implementation and storage remain unchanged.
- Checked completion tags and both synthesis conventions. Default/explicit NLFT retains no ratio; RHW retains and dispatches through the ratio payload. Common outer-factor arithmetic retains its order. Four/five transform charging, residual charges, and cumulative binary64 refinement budget are consistent. Offline FFT charging remains precision-weighted and cumulative while skipping the NLFT ratio transform. Selected ratio memory is explicitly reserved.
- Inspected matching Nix MPI wrapper, linker input and launcher selection, Linux MPI/SUBCOMM flags, explicit installed MPI RUNPATH, independent `dlopen` check, and CPU-only installed consumer initialization. Darwin's MPI-off/OpenMP selection and minimal-example entrypoint remain selected by platform conditions. The common installed consumer check changes also apply on Darwin; execution there remains unverified.
- Read native derivation/clean-shell/Darwin evaluation reports and all-feature completion/shared reports. Confirmed the documented `devenv --clean shell` syntax parses as the shell subcommand using CLI help.
- Fresh `cargo test -p quest-numerics --test shared_convolution --all-features --locked`: exit 0, 10 passed.
- Fresh `cargo test -p quest-qsp --test completion_outer --all-features --locked`: exit 0, 4 passed; existing quest-polynomial nightly trait-solver warning observed.
- Fresh `git diff --check`: exit 0.

Both focused test commands used `CARGO_TARGET_DIR=<artifacts>/focused` and `CARGO_BUILD_JOBS=2` from this worktree.

## Limits

Full workspace all-feature acceptance, installed system-lane runtime checks, real multi-rank MPI runs, ignored release tests, Darwin build/runtime, and staged performance evidence were not independently executed in this review. Native build claims above rely on retained task evidence. No performance claim is made. No production or test sources were edited.
