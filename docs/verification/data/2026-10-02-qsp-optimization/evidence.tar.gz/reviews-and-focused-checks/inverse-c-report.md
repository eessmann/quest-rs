# C: shared inverse transforms and compact product windows

Implemented only the inverse portions of `crates/quest-qsp/src/kernel.rs`, `offline/kernels.rs`, and `offline/fft.rs`, after the parent confirmed the A+B snapshot. No shared-numerics API changes, commits, or additional agents.

## Binary64

The inverse uses a private `SharedConvolutions` plan cache distinct from ordinary completion/reconstruction convolution. Plans call `SharedConvolutionWorkspace::new_with_policy(size,size,...)`, with `size=max_operand.next_power_of_two()` exactly as before. Midpoint and reconstruction groups borrow the two immutable RHS inputs through `session([right0,right1],execution)`, select them in `[0,1,1,0]` order, charge `work_for(index)` before each `product(left,index)`, and copy only the needed output window. Plan bytes include the third L-length array and all admitted FFT scratch/planner estimates across retained sizes. Cold/warm work is `3*T+L` / `2*T+L` with `T=8*L*max(log2(L),1)`; a group removes exactly two RHS transforms.

Midpoint windows are four lower-length slices. Reconstruction copies the two shifted windows of length count-1 and two unshifted windows of length count (including the same implicit out-of-support zeros). All four products finish before the original interleaved finite additions/subtractions. Combination consumes exactly four windows and reuses ea/eb as midpoint_a/b or xe/ee as xi/eta, preserving the same operand and per-index error order without allocating two additional output vectors. The other two midpoint windows and session borrows end before lower recursion; the reused midpoint pair is explicitly dropped after lower recursion and before reconstruction. Full product vectors are not retained. Multiplication left/right order, sharp/reversed conjugate inputs, forward/inverse normalization, backend selection and parallel thresholds are unchanged.

## Offline

A private group-scoped `SharedConvolutionSession` retains reusable left/product storage and two lazily prepared RHS spectra. It calls the original `transform` implementation and `Context` twiddle cache, preserving MP Number operation order, precision, signed zeros and cumulative precision-limb weighting. The original zero shortcut precedes direct/FFT work/admission; support <=16 uses the original i-then-j direct multiply/add loop. FFT padding remains the previous support.next_power_of_two(), without applying binary64's different padding rule. Cold products run left forward, selected RHS forward, inverse; warm products omit only selected RHS forward. Original offline FFT/twiddle/direct accounting constants remain unchanged, including no new pointwise multiplication charge.

Sessions and their three complex arrays are destroyed at group return, before recursive descent. At maximum FFT length L, these arrays occupy 6*L modeled Binary scalars; cumulative radix-2 cached roots occupy fewer than 2*L scalars, and scalar arithmetic scratch remains within the existing conservative 32*grid allowance. Compact windows (four live during combination, two reused as eventual outputs) and live parent/child transfer payloads use the separate count*levels*32 recursive scalar allowance. No extra pair of output Vec buffers is admitted or allocated by combination. Thus the existing modeled storage envelope covers all concurrently live spectra/scratch without double-counting a second live FFT group. Exact modeled byte boundaries remain tested. These are modeled algorithmic resources, not a process-wide quota on backend internals.

## Exact verification

Independent pre-B full-transfer recursion retained in both test modules uses ordinary convolutions. Tests now compare root reflections AND complete xi/eta transfers against it: binary64 component bits and offline represented values, configured precision, and negative-zero state. Work assertions independently sum the two omitted RHS transforms per eligible group plus B's omitted root transfer work. Pointer-and-capacity identity tests verify that midpoint and transfer helpers return the selected original window storage, including offline at65/128/256 bits. The conservative admitted scalar envelope remains unchanged; reuse reduces live allocations within that envelope and existing exact inclusive admission boundaries remain verified.

Coverage includes singleton, odd/even supports, binary64 degrees through 255, offline coefficient counts through65 at 65/128/256 bits, direct product supports15/16 and FFT17/23, zero paths, exact inclusive work/byte admission, fresh-session work, RHS invalidation/recovery after failure, repeatability, each available scalar/SIMD backend, and 1025-coefficient 1/2/4-worker runs crossing the parallel FFT threshold. Optional SIMD tests return only on the existing BackendUnavailable contract.

All commands used cwd `<worktree>`, `CARGO_TARGET_DIR=<artifacts>/focused`, `CARGO_BUILD_JOBS=2`.

| Command | Exit | Evidence |
| --- | --- | --- |
| `cargo test -p quest-qsp --all-features --lib reflections_only --locked` | 0 | Initial exact C reflection oracles; `inverse-c-oracles.log` |
| `cargo test -p quest-qsp --all-features --lib shared --locked` | 0 | Five group/backend/pool tests; `inverse-c-shared-tests.log` |
| `cargo test -p quest-qsp --all-features --locked` | 0 | 126 passed, 3 ignored including doctests; `inverse-c-reuse-all-features.log` |
| `cargo test -p quest-qsp --no-default-features --locked` | 0 | 38 passed including doctests; `inverse-c-reuse-scalar.log` |
| `cargo test -p quest-qsp --no-default-features --features offline-synthesis --lib --locked` | 0 | 40 passed, 1 ignored; `inverse-c-reuse-offline-scalar.log` |
| `cargo clippy -p quest-qsp --all-features --all-targets --locked -- -D warnings` | 0 | `inverse-c-reuse-clippy.log` |
| `cargo clippy -p quest-qsp --no-default-features --all-targets --locked -- -D warnings` | 0 | `inverse-c-reuse-scalar-clippy.log` |
| `cargo clippy -p quest-qsp --no-default-features --features offline-synthesis --all-targets --locked -- -D warnings` | 0 | `inverse-c-reuse-offline-scalar-clippy.log` |
| Scoped rustfmt check on the three owned sources | 0 | `--edition 2024 --config skip_children=true` |
| `git diff --check` | 0 | No whitespace errors |

Initial C oracle run intentionally retained B's work expectation and failed after observing the new saved FFT charges; exact values already matched. Work assertions were updated to independently include C savings. Strict Clippy caught a long test literal, an idiom, an unfulfilled test annotation, and an overlong offline recurrence; fixes included extracting the offline leaf helper with no production lint suppression. Full/native workspace, ignored-release acceptance and benchmark evidence remain the parent task's responsibility. No measured speedup claim.

The parent's follow-up review identified the initial six-window/output buffer footprint. Final code now reuses two of four windows as outputs for both backends and explicitly releases midpoint storage before reconstruction. Final reruns above use separate `inverse-c-reuse-*` logs; initial C evidence is preserved. No further source edits are planned.

Production source is frozen and ready for the A+B+C snapshot. SHA-256 identities:


- `crates/quest-qsp/src/kernel.rs`: `108016649f028d436c9a8c384a9fb96793ea0c623fcfec8061e4b4ee6561c3a1`
- `crates/quest-qsp/src/offline/kernels.rs`: `5edde0ea61ad1a3712121343aaf12df5603c85b045a557a17cc756430a728b5d`
- `crates/quest-qsp/src/offline/fft.rs`: `5bcb3b6c43310fdfed01faf0fa8c196b876aaa82ec1793a0367038e437665e10`
