# B: reflections-only inverse root

Implemented `kernel.rs` and `offline/kernels.rs` only. Root recursion requests reflections and omits final four transfer products and xi/eta output allocation. Both upper and lower recursive children explicitly request full transfer, preserving dependency/arithmetic order. A singleton root still performs pivot/support/finite validation, then returns its reflection without normalization or leaf-transfer allocation.

Extracted one scalar control helper per backend. The binary64 arithmetic statements are unchanged. Offline `controls` retains aggregate upfront `64*count` charge; non-root leaves charge 64 directly before the same scalar normalization. A singleton root removes its unused 64-unit (precision-weighted) normalization.

Retained independent pre-B full-transfer recursion in tests, using ordinary convolution. Binary64 checks exact component bits for 1/2/3/5/8/17/32/65 coefficients; offline checks exact MP values, precision and signed-zero identity at 65/128/256 bits for 1/2/3/5/8/17/32 coefficients. Tests verify root-only work savings, exact inclusive work/byte limits, and singular/nonfinite singleton behavior. The oracles intentionally remain available for C regression validation.

All commands used cwd `<worktree>`, `CARGO_TARGET_DIR=<artifacts>/focused`, `CARGO_BUILD_JOBS=2`.

- `cargo test -p quest-qsp --all-features --lib inverse --locked`: exit 0, two binary64 tests, `inverse-b-test.log`.
- `cargo test -p quest-qsp --all-features --lib reflections_only --locked`: exit 0, both backend exact oracles, `inverse-b-offline-test.log`.
- `cargo test -p quest-qsp --all-features --locked`: exit 0, all package tests/doctests, `inverse-b-all-features.log`.
- `cargo clippy -p quest-qsp --all-features --all-targets --locked -- -D warnings`: exit 0, `inverse-b-clippy.log`.
- Scoped `rustfmt --check --config skip_children=true` on the two owned sources: exit 0.
- `git diff --check`: exit 0.

Initial test compile exposed a googletest `Result` glob collision, fixed by explicit import. Initial strict Clippy identified test assertion annotation/initializer issues and one moved scalar's redundant clone, all corrected; no production lint suppression added. No benchmark or whole-workspace/native validation claim.

B source is frozen for the parent's A+B snapshot. C has not begun.
