# SDD ledger — plan: docs/superpowers/plans/2026-10-02-all-features-qsp.md

Approved plan is also the spec. Implementation worktree: target/worktrees/all-features-qsp, branch codex/all-features-qsp. Immutable baseline archive and extraction in parent target/qsp-optimization. No main source edits.

## Preflight
| Tasks | Shared boundary | Resolution |
|---|---|---|
| Native / A / numerics | no shared edits | parallel ownership |
| A / B / C | qsp kernel/offline/stages | A then B then C sequential; snapshots at boundaries |
| Numerics / C | shared workspace public API | fixed approved session API, consumed only after implementation |
| Measurements / stages | source identity | immutable extracted snapshots; don't time during competing builds |
| Native | SDK consistency / test registration | matched MPICH within each lane; CPU install check separate from MPI tests |
| A | API matches algorithm / budget | tagged payload; four vs five FFTs |
| B | root-only pruning | children remain full transfer |
| C | borrowed buffers vs error order | copy windows first, combine after all products |
| Evidence | staged timings / strict correctness | all failures retained, no claims for unrun work |

## Progress
- Baseline d19de2a archived and extracted.
- Task 1 native setup: complete; both final environment acceptance matrices passed.
- Task 2 A: complete; exact and feature-gated regressions passed; independently reviewed.
- Task 3 shared numerics: complete; scalar/all-feature checks and independent review passed.
- Task 4 B: complete; immutable A+B snapshot and exact ordinary-convolution oracle verified; reviewed.
- Task 5 C integration: complete including in-place reuse; exact backends/pools/resource tests pass; reviewed.
- Task 6 verification and benchmarks: complete; both matrices and72-record campaign passed; no outstanding review findings.
- Native configuration implemented; Nix package/install+dlopen checked and Darwin eval only. System baseline workspace allfeatures build passed; clean Nix baseline allfeatures build passed. Both baseline nextest runs ongoing.
- A complete, tests (109 +8 docs allfeatures;29+5 default) and strictClippy pass. Immutable snapshot-a and A benchmark build captured; initial review ongoing.
- Shared numerics complete, tests (82+4 docs allfeatures;75+4 scalar) and strictClippy pass; initial review ongoing.
- B implementer dispatched with STOP after B for snapshot handshake; C only after parent signal.
- Benchmark driver/harness added; baseline instrumented observer built. Instrumentation only in copied sources, original/modified hashes retained; no timed campaign started during builds.
- Initial independent review Native+A+Shared: no actionable findings, additional focused tests passed (initial-review.md).
- Baseline system nextest FAIL exit100: 988 passed, one compilefail std::Vec diagnostic layout mismatch under newer nightly,102 notrun via failfast,3 intentionallyignored. Portable !Send test fix dispatched; preserve true negative trait contract without stdsource snapshot coupling. Final full runs required.
- A observer build passed. Baseline observer smoke running; concurrent build timings explicitly excluded from campaign.
- B complete: exact binary64/MP oracle tests, full package suite and strictClippy passed. Snapshot-ab captured and observer built. C in progress; initial exact oracles pass.
- Baseline Nix nextest PASS1091 across166 binaries,3ignored. New portableSend assertion actual/typecontrol verified bothcompiler versions and bothfocusednextest suites passed.
- Current Nix native installed consumers CPU/OMP passed fullclosure checks. Current system consumers running.
- Binding freshness FAIL both lanes; rendered scratch diagnosis: exactly one added conditional MPI initializer, common747 inventory entries unchanged. Generator portability fix delegated (conditional coverage partition), production generated bridges unaffected.

- C final in-place window reuse validated:126 allfeature tests/docs,38 scalar,40 offline-only; strictClippy all3 modes. ABC snapshot and reconstructible patches captured and independently checked.
- Binding repair common747 manifest/production Rust+CXX unchanged; system+cleanNix freshness and43xtasktests passed. Full native installed CPU/OMP consumers passed bothlanes.
- Initial final acceptance reused baseline target artifacts and exposed stale Cargo variants (E0432). Preserved failures and dep-info evidence; restarted bothfinal lanes with entirelyempty separate targets.
- Freshfinal system and cleanNix builds passed. Both fullnextest1120tests passed with3intentionalignored; separatefullworkspace doctests passed. Releaseignored/strictClippy/finalbinding gates ongoing.
- Final independent production review found no actionable defects. Earlier twofixtureP2 issues repaired; freshcontroller/allocator tests and independent stagedpatch reconstruction passed. Summarynormalization andreceiptgates reviewed.
- Allfour instrumented observers built with separate pervarianttargetdirs. Official timingcampaign has not started; waitforbuilds/testsidle.

- Final system acceptance4 and devenv acceptance3 passed1120workspace tests +65docs +strictallfeatureClippy +fmt/build. Three ignoredreleasefixtures passedboth (unchanged QSPsource). RealMPICH2/4rankexplicitcasespassedboth; nativeconsumers/bindings passed.
- Final style repairs: existing CLI constructor field order and byte-identical testmodule relocation; both reviewed and both full matrices repeated. No lint suppressions or numerical tolerance changes.
- Official campaign completed12successfultrials/72records, matched all exportfingerprints/grids/sourceidentities. Interleaved baseline/A/AB/ABC, no competingbuilds/tests. Matched compiler/config/dependencies/fixturecodesverified.
- Observed full-vs-baseline median end-to-end reductions: binary64degree25619.22%,degree102417.02%;offline2.43–7.94%. Offlineintermediate timingsnonmonotonic; offlinewhole-solvepeakunchanged. Alltables/minmax/resourcesretained; no historicDashuregexplanationclaimed.
