# Astro-float / Rug fixed-precision benchmark

This excluded workspace fixture pins Astro-float 0.9.6 and Rug 1.30.0 independently
of the production backend. The checked-in lockfile also records native bindings
(`gmp-mpfr-sys` 1.7.1). It runs single-threaded in release mode with thin LTO and
one codegen unit. Generated `target/` files are ignored by the repository.

From the repository root, using its configured toolchain:

```sh
CARGO_BUILD_JOBS=2 devenv shell -- cargo build --release --locked --manifest-path docs/verification/fixtures/mp-backends/Cargo.toml
CARGO_BUILD_JOBS=2 devenv shell -- cargo run --release --locked --manifest-path docs/verification/fixtures/mp-backends/Cargo.toml -- --verify
CARGO_BUILD_JOBS=2 devenv shell -- cargo run --release --locked --manifest-path docs/verification/fixtures/mp-backends/Cargo.toml > bench-raw.csv 2> bench-run.log
python3 docs/verification/fixtures/mp-backends/summarize.py bench-raw.csv bench-summary.csv
```

The benchmark validates before timing. Do not run competing builds during the
timed command. Warm constants, input generation, and mathematical witnesses are
outside the measured loops. Each row reports process CPU and monotonic wall time;
the unit is one operation, one pair of directed endpoints, or one complete kernel,
as identified by the workload column. Eight warmup calls precede each row.

All inputs are deterministic binary strings with 128, 256, or 512 significant
bits. These precisions match Astro's whole-word rounding on this host. Exact
integer-mantissa/exponent conversion checks the stored operands without an f64
round trip. Fresh-output operations allocate and destroy one result per operation
on both libraries. Rug reuse rows assign into previously allocated outputs;
transcendental reuse includes assigning the source before each in-place call.
They are a separate API opportunity, not the main comparison.

Three interleaved trials rotate backend order. `add`, `mul`, and `div` use nearest
ties-to-even. `exp`, `ln`, `sin`, and `cos` evaluate both downward and upward
endpoints of each point. No fused operations, approximate rounding, or f64
conversions substitute for any measured arithmetic. Matrix multiplication and
modified Gram-Schmidt QR operate on a deterministic 16 by 16 diagonally dominant
matrix with fresh scalar outputs, using the same generic algorithm for both
libraries. QR is a workload proxy, not quest-polynomial's Householder solver.

At each precision, verification checks 256 exact input pairs, 48 matched nearest
arithmetic results, 64 transcendental lower/upper pairs for each backend against
2048-bit MPFR directed witnesses, 256 matched matrix entries, and 512 QR
reconstruction/orthogonality inequalities for each backend. The QR tolerance is
`2^(-p+32)` in absolute units. MPFR witnesses independently check Astro but do not
constitute an independent implementation oracle for Rug itself.

See [the local result report](results/2026-10-02/report.md),
[225 raw trial rows](results/2026-10-02/raw.csv), and
[per-workload medians and ranges](results/2026-10-02/summary.csv).

