#!/usr/bin/env python3
"""Summarize the raw CPU and wall timings without external dependencies."""
import csv
import statistics
import sys
from collections import defaultdict

if len(sys.argv) != 3:
    raise SystemExit("usage: summarize.py RAW.csv SUMMARY.csv")

groups = defaultdict(list)
with open(sys.argv[1], newline="") as source:
    for row in csv.DictReader(source):
        key = (int(row["bits"]), row["backend"], row["allocation"], row["workload"])
        groups[key].append(row)

with open(sys.argv[2], "w", newline="") as output:
    fields = ["bits", "backend", "allocation", "workload", "trials",
              "cpu_ns_median", "cpu_ns_min", "cpu_ns_max", "wall_ns_median",
              "wall_ns_min", "wall_ns_max", "astro_fresh_cpu_speedup"]
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    for (bits, backend, allocation, workload), rows in sorted(groups.items()):
        assert len(rows) == 3
        assert {row["trial"] for row in rows} == {"0", "1", "2"}
        cpu = [float(row["cpu_ns_per_iteration"]) for row in rows]
        wall = [float(row["wall_ns_per_iteration"]) for row in rows]
        baseline = [float(row["cpu_ns_per_iteration"])
                    for row in groups[bits, "astro", "fresh", workload]]
        writer.writerow(dict(zip(fields, [bits, backend, allocation, workload,
            len(rows), statistics.median(cpu), min(cpu), max(cpu),
            statistics.median(wall), min(wall), max(wall),
            statistics.median(baseline) / statistics.median(cpu)])))
