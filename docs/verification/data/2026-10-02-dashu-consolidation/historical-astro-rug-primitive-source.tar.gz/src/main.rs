//! Isolated fixed-precision comparison. Run `--verify` before timed execution.
use astro_float::{BigFloat, Consts, Radix, RoundingMode, Sign};
use rug::{Assign, Float, Integer, float::Round};
use std::{hint::black_box, time::Instant};

const N: usize = 16;
const WITNESS_BITS: u32 = 2048;

trait Ops {
    type S: Clone;
    fn integer(&self, n: i64) -> Self::S;
    fn add(&self, a: &Self::S, b: &Self::S) -> Self::S;
    fn sub(&self, a: &Self::S, b: &Self::S) -> Self::S;
    fn mul(&self, a: &Self::S, b: &Self::S) -> Self::S;
    fn div(&self, a: &Self::S, b: &Self::S) -> Self::S;
    fn sqrt(&self, a: &Self::S) -> Self::S;
    fn exact(&self, a: &Self::S) -> Float;
}

struct Astro(usize);
impl Ops for Astro {
    type S = BigFloat;
    fn integer(&self, n: i64) -> BigFloat { BigFloat::from_i64(n, self.0) }
    fn add(&self, a: &BigFloat, b: &BigFloat) -> BigFloat { a.add(b, self.0, RoundingMode::ToEven) }
    fn sub(&self, a: &BigFloat, b: &BigFloat) -> BigFloat { a.sub(b, self.0, RoundingMode::ToEven) }
    fn mul(&self, a: &BigFloat, b: &BigFloat) -> BigFloat { a.mul(b, self.0, RoundingMode::ToEven) }
    fn div(&self, a: &BigFloat, b: &BigFloat) -> BigFloat { a.div(b, self.0, RoundingMode::ToEven) }
    fn sqrt(&self, a: &BigFloat) -> BigFloat { a.sqrt(self.0, RoundingMode::ToEven) }
    fn exact(&self, a: &BigFloat) -> Float { exact_astro(a) }
}

struct Rug(u32);
impl Ops for Rug {
    type S = Float;
    fn integer(&self, n: i64) -> Float { Float::with_val(self.0, n) }
    fn add(&self, a: &Float, b: &Float) -> Float { Float::with_val(self.0, a + b) }
    fn sub(&self, a: &Float, b: &Float) -> Float { Float::with_val(self.0, a - b) }
    fn mul(&self, a: &Float, b: &Float) -> Float { Float::with_val(self.0, a * b) }
    fn div(&self, a: &Float, b: &Float) -> Float { Float::with_val(self.0, a / b) }
    fn sqrt(&self, a: &Float) -> Float { Float::with_val(self.0, a.sqrt_ref()) }
    fn exact(&self, a: &Float) -> Float { Float::with_val(WITNESS_BITS, a) }
}

fn exact_astro(x: &BigFloat) -> Float {
    assert!(!x.is_nan() && !x.is_inf());
    let (words, _, sign, exponent, _) = x.as_raw_parts().unwrap();
    let mut integer = Integer::new();
    for word in words.iter().rev() {
        integer <<= astro_float::WORD_BIT_SIZE as u32;
        integer += *word;
    }
    if sign == Sign::Neg { integer = -integer; }
    let mut result = Float::with_val(WITNESS_BITS, integer);
    result <<= exponent - (words.len() * astro_float::WORD_BIT_SIZE) as i32;
    result
}

// Every input is an exactly representable p-bit binary fraction, generated as a
// string. Neither input construction nor correctness checks round through f64.
fn binary_input(bits: usize, seed: usize) -> String {
    let mut state = seed as u64 + 0x9876_5432_1234;
    let mut text = String::from("0.1");
    for _ in 1..bits {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        text.push(if state & 1 == 0 { '0' } else { '1' });
    }
    text
}

fn inputs(p: usize) -> (Vec<BigFloat>, Vec<Float>) {
    let mut constants = Consts::new().unwrap();
    let mut astro = Vec::new();
    let mut rug = Vec::new();
    for i in 0..N * N {
        let text = binary_input(p, i);
        let a = BigFloat::parse(&text, Radix::Bin, p, RoundingMode::ToEven, &mut constants);
        let r = Float::with_val(p as u32, Float::parse_radix(&text, 2).unwrap());
        assert_eq!(exact_astro(&a), r);
        astro.push(a);
        rug.push(r);
    }
    (astro, rug)
}

fn matrix<B: Ops>(b: &B, input: &[B::S]) -> Vec<B::S> {
    let mut result = input.to_vec();
    let diagonal = b.integer(20);
    for i in 0..N { result[i * N + i] = b.add(&result[i * N + i], &diagonal); }
    result
}

fn matmul<B: Ops>(b: &B, a: &[B::S]) -> Vec<B::S> {
    let mut c = vec![b.integer(0); N * N];
    for i in 0..N {
        for j in 0..N {
            for k in 0..N {
                c[i * N + j] = b.add(&c[i * N + j], &b.mul(&a[i * N + k], &a[k * N + j]));
            }
        }
    }
    c
}

// Modified Gram-Schmidt is an algorithmic workload, not a claim that it matches
// quest-polynomial's pivoted Householder implementation or its allocation policy.
fn qr<B: Ops>(b: &B, a: &[B::S]) -> (Vec<B::S>, Vec<B::S>) {
    let mut q = a.to_vec();
    let mut r = vec![b.integer(0); N * N];
    for k in 0..N {
        let mut norm = b.integer(0);
        for i in 0..N { norm = b.add(&norm, &b.mul(&q[i * N + k], &q[i * N + k])); }
        r[k * N + k] = b.sqrt(&norm);
        for i in 0..N { q[i * N + k] = b.div(&q[i * N + k], &r[k * N + k]); }
        for j in k + 1..N {
            let mut projection = b.integer(0);
            for i in 0..N { projection = b.add(&projection, &b.mul(&q[i * N + k], &q[i * N + j])); }
            r[k * N + j] = projection.clone();
            for i in 0..N { q[i * N + j] = b.sub(&q[i * N + j], &b.mul(&q[i * N + k], &projection)); }
        }
    }
    (q, r)
}

fn astro_trans(op: usize, x: &BigFloat, p: usize, round: RoundingMode, c: &mut Consts) -> BigFloat {
    match op {
        0 => x.exp(p, round, c),
        1 => x.ln(p, round, c),
        2 => x.sin(p, round, c),
        3 => x.cos(p, round, c),
        _ => unreachable!(),
    }
}

fn rug_trans(op: usize, x: &Float, p: u32, round: Round) -> Float {
    match op {
        0 => Float::with_val_round(p, x.exp_ref(), round).0,
        1 => Float::with_val_round(p, x.ln_ref(), round).0,
        2 => Float::with_val_round(p, x.sin_ref(), round).0,
        3 => Float::with_val_round(p, x.cos_ref(), round).0,
        _ => unreachable!(),
    }
}

fn assert_small(value: &Float, p: usize, name: &str) {
    let mut tolerance = Float::with_val(WITNESS_BITS, 1);
    tolerance >>= p as i32 - 32;
    assert!(value.clone().abs() <= tolerance, "{name}: {value}");
}

fn verify_qr<B: Ops>(b: &B, a: &[B::S], p: usize) {
    let (q, r) = qr(b, a);
    let high = Rug(WITNESS_BITS);
    let q: Vec<_> = q.iter().map(|v| b.exact(v)).collect();
    let r: Vec<_> = r.iter().map(|v| b.exact(v)).collect();
    for i in 0..N {
        for j in 0..N {
            let mut reconstructed = high.integer(0);
            let mut orthogonal = high.integer(0);
            for k in 0..N {
                reconstructed += high.mul(&q[i * N + k], &r[k * N + j]);
                orthogonal += high.mul(&q[k * N + i], &q[k * N + j]);
            }
            assert_small(&high.sub(&reconstructed, &b.exact(&a[i * N + j])), p, "QR residual");
            assert_small(&high.sub(&orthogonal, &high.integer(i64::from(i == j))), p, "QR orthogonality");
        }
    }
}

fn verify(p: usize, a: &[BigFloat], r: &[Float]) {
    let ab = Astro(p);
    let rb = Rug(p as u32);
    let mut constants = Consts::new().unwrap();
    for i in 0..N {
        let j = (i + 1) % N;
        for (aa, rr) in [
            (ab.add(&a[i], &a[j]), rb.add(&r[i], &r[j])),
            (ab.mul(&a[i], &a[j]), rb.mul(&r[i], &r[j])),
            (ab.div(&a[i], &a[j]), rb.div(&r[i], &r[j])),
        ] { assert_eq!(exact_astro(&aa), rr, "matched nearest arithmetic at {p} bits"); }
        for op in 0..4 {
            let lo = astro_trans(op, &a[i], p, RoundingMode::Down, &mut constants);
            let hi = astro_trans(op, &a[i], p, RoundingMode::Up, &mut constants);
            let truth_input = Float::with_val(WITNESS_BITS, &r[i]);
            let truth_lo = rug_trans(op, &truth_input, WITNESS_BITS, Round::Down);
            let truth_hi = rug_trans(op, &truth_input, WITNESS_BITS, Round::Up);
            assert!(exact_astro(&lo) <= truth_lo && exact_astro(&hi) >= truth_hi);
            assert!(rug_trans(op, &r[i], p as u32, Round::Down) <= truth_lo);
            assert!(rug_trans(op, &r[i], p as u32, Round::Up) >= truth_hi);
        }
    }
    let am = matrix(&ab, a);
    let rm = matrix(&rb, r);
    let aa = matmul(&ab, &am);
    let rr = matmul(&rb, &rm);
    for (av, rv) in aa.iter().zip(&rr) { assert_eq!(exact_astro(av), *rv); }
    verify_qr(&ab, &am, p);
    verify_qr(&rb, &rm, p);
    eprintln!("verified bits={p}: 256 exact input pairs, 48 nearest outputs, 128 directed pairs, 256 matrix outputs, 512 QR residual/orthogonality witnesses per backend");
}

fn cpu_ns() -> u64 {
    let mut t = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    // SAFETY: a writable timespec is passed and the status is checked.
    let status = unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut t) };
    assert_eq!(status, 0);
    t.tv_sec as u64 * 1_000_000_000 + t.tv_nsec as u64
}

fn measure(mut f: impl FnMut(), trial: usize, p: usize, backend: &str, mode: &str, workload: &str, count: usize) {
    for _ in 0..8 { f(); }
    let start_cpu = cpu_ns();
    let start_wall = Instant::now();
    for _ in 0..count { f(); }
    let wall = start_wall.elapsed().as_nanos();
    let cpu = cpu_ns() - start_cpu;
    println!("{trial},{p},{backend},{mode},{workload},{count},{cpu},{wall},{:.3},{:.3}", cpu as f64 / count as f64, wall as f64 / count as f64);
}

fn primitives(trial: usize, p: usize, backend: usize, a: &[BigFloat], r: &[Float]) {
    let ab = Astro(p);
    let rb = Rug(p as u32);
    for (op, name) in ["add", "mul", "div"].into_iter().enumerate() {
        let mut i = 0;
        let mut reusable = Float::new(p as u32);
        let mut run = || {
            i = (i + 1) % N;
            let j = (i + 1) % N;
            match backend {
                0 => { black_box(match op { 0 => ab.add(black_box(&a[i]), black_box(&a[j])), 1 => ab.mul(black_box(&a[i]), black_box(&a[j])), _ => ab.div(black_box(&a[i]), black_box(&a[j])) }); }
                1 => { black_box(match op { 0 => rb.add(black_box(&r[i]), black_box(&r[j])), 1 => rb.mul(black_box(&r[i]), black_box(&r[j])), _ => rb.div(black_box(&r[i]), black_box(&r[j])) }); }
                2 => {
                    match op {
                        0 => reusable.assign(black_box(&r[i]) + black_box(&r[j])),
                        1 => reusable.assign(black_box(&r[i]) * black_box(&r[j])),
                        _ => reusable.assign(black_box(&r[i]) / black_box(&r[j])),
                    }
                    black_box(&reusable);
                }
                _ => unreachable!(),
            }
        };
        let (backend_name, mode) = match backend { 0 => ("astro", "fresh"), 1 => ("rug", "fresh"), _ => ("rug", "reuse") };
        measure(&mut run, trial, p, backend_name, mode, name, 200_000);
    }
}

fn transcendentals(trial: usize, p: usize, backend: usize, a: &[BigFloat], r: &[Float]) {
    let mut constants = Consts::new().unwrap();
    for (op, name) in ["exp_endpoints", "ln_endpoints", "sin_endpoints", "cos_endpoints"].into_iter().enumerate() {
        let mut i = 0;
        let mut lo = Float::new(p as u32);
        let mut hi = Float::new(p as u32);
        let mut run = || {
            i = (i + 1) % N;
            match backend {
                0 => {
                    black_box(astro_trans(op, black_box(&a[i]), p, RoundingMode::Down, &mut constants));
                    black_box(astro_trans(op, black_box(&a[i]), p, RoundingMode::Up, &mut constants));
                }
                1 => {
                    black_box(rug_trans(op, black_box(&r[i]), p as u32, Round::Down));
                    black_box(rug_trans(op, black_box(&r[i]), p as u32, Round::Up));
                }
                2 => {
                    lo.assign(black_box(&r[i]));
                    hi.assign(black_box(&r[i]));
                    match op {
                        0 => { lo.exp_round(Round::Down); hi.exp_round(Round::Up); }
                        1 => { lo.ln_round(Round::Down); hi.ln_round(Round::Up); }
                        2 => { lo.sin_round(Round::Down); hi.sin_round(Round::Up); }
                        _ => { lo.cos_round(Round::Down); hi.cos_round(Round::Up); }
                    }
                    black_box((&lo, &hi));
                }
                _ => unreachable!(),
            }
        };
        let (backend_name, mode) = match backend { 0 => ("astro", "fresh"), 1 => ("rug", "fresh"), _ => ("rug", "reuse") };
        measure(&mut run, trial, p, backend_name, mode, name, 2_000);
    }
}

fn algorithms(trial: usize, p: usize, backend: usize, a: &[BigFloat], r: &[Float]) {
    if backend == 0 {
        let b = Astro(p);
        let matrix = matrix(&b, a);
        measure(|| { black_box(matmul(&b, black_box(&matrix))); }, trial, p, "astro", "fresh", "matmul16", 50);
        measure(|| { black_box(qr(&b, black_box(&matrix))); }, trial, p, "astro", "fresh", "qr16", 50);
    } else if backend == 1 {
        let b = Rug(p as u32);
        let matrix = matrix(&b, r);
        measure(|| { black_box(matmul(&b, black_box(&matrix))); }, trial, p, "rug", "fresh", "matmul16", 50);
        measure(|| { black_box(qr(&b, black_box(&matrix))); }, trial, p, "rug", "fresh", "qr16", 50);
    }
}

fn main() {
    let verify_only = std::env::args().any(|x| x == "--verify");
    let fixtures: Vec<_> = [128, 256, 512].into_iter().map(|p| {
        let (a, r) = inputs(p);
        verify(p, &a, &r);
        (p, a, r)
    }).collect();
    if verify_only { return; }
    println!("trial,bits,backend,allocation,workload,iterations,cpu_ns,wall_ns,cpu_ns_per_iteration,wall_ns_per_iteration");
    // Latin-square order balances startup and thermal order across three trials.
    // Each workload class is interleaved across backends, rather than completing
    // all Astro trials before starting Rug trials.
    for trial in 0..3 {
        for (p, a, r) in &fixtures {
            for order in 0..3 { primitives(trial, *p, (order + trial) % 3, a, r); }
            for order in 0..3 { transcendentals(trial, *p, (order + trial) % 3, a, r); }
            for order in 0..3 { algorithms(trial, *p, (order + trial) % 3, a, r); }
        }
    }
}
