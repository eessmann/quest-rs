#![allow(
    clippy::as_conversions,
    clippy::cast_possible_truncation,
    clippy::cast_possible_wrap,
    reason = "Oracle fixtures use bounded exponents and mantissas below 1024 bits"
)]
#![allow(
    clippy::unwrap_used,
    clippy::indexing_slicing,
    clippy::arithmetic_side_effects,
    clippy::float_cmp,
    clippy::panic,
    clippy::panic_in_result_fn,
    reason = "Bounded analytic fixtures intentionally use exact assertions and fail immediately"
)]
//! Independent MPFR checks. No production dependency on the oracle.
use astro_float::{BigFloat, Sign};
use quest_numerics::arithmetic::*;
use rug::{Float, Integer, float::Round};
const ORACLE: u32 = 1024;
fn exact_rug(x: &BigFloat) -> Float {
    let (words, _, sign, exponent, _) = x.as_raw_parts().unwrap();
    let mut integer = Integer::from(0);
    for word in words.iter().rev() {
        integer <<= astro_float::WORD_BIT_SIZE as u32;
        integer += *word;
    }
    if sign == Sign::Neg {
        integer = -integer;
    }
    let mut x = Float::with_val(ORACLE, integer);
    x <<= exponent - (words.len() * astro_float::WORD_BIT_SIZE) as i32;
    x
}
#[allow(
    clippy::needless_pass_by_value,
    reason = "Oracle bounds are temporary consumed expectations"
)]
fn encloses(x: &MpInterval, lo: Float, hi: Float) {
    assert!(exact_rug(x.lower()) <= lo, "lower endpoint");
    assert!(exact_rug(x.upper()) >= hi, "upper endpoint");
}
#[test]
fn mpfr_directed_transcendentals_and_basic_arithmetic() {
    let mut b = MpIntervalBackend::new(Precision {
        bits: 128,
        ..Default::default()
    })
    .unwrap();
    for value in [0.125, 0.5, 1.0, 1.5, 10.0, 100.0] {
        let x = b.point(value).unwrap();
        let r = Float::with_val(ORACLE, value);
        encloses(
            &b.exp(x.clone()).unwrap(),
            Float::with_val_round(ORACLE, r.exp_ref(), Round::Down).0,
            Float::with_val_round(ORACLE, r.exp_ref(), Round::Up).0,
        );
        encloses(
            &b.ln(x.clone()).unwrap(),
            Float::with_val_round(ORACLE, r.ln_ref(), Round::Down).0,
            Float::with_val_round(ORACLE, r.ln_ref(), Round::Up).0,
        );
        encloses(
            &b.sqrt(x.clone()).unwrap(),
            Float::with_val_round(ORACLE, r.sqrt_ref(), Round::Down).0,
            Float::with_val_round(ORACLE, r.sqrt_ref(), Round::Up).0,
        );
        encloses(
            &b.sin(x.clone()).unwrap(),
            Float::with_val_round(ORACLE, r.sin_ref(), Round::Down).0,
            Float::with_val_round(ORACLE, r.sin_ref(), Round::Up).0,
        );
        encloses(
            &b.cos(x.clone()).unwrap(),
            Float::with_val_round(ORACLE, r.cos_ref(), Round::Down).0,
            Float::with_val_round(ORACLE, r.cos_ref(), Round::Up).0,
        );
        let y = b.point(3.0).unwrap();
        let three = Float::with_val(ORACLE, 3);
        encloses(
            &b.div(x, y).unwrap(),
            Float::with_val_round(ORACLE, &r / &three, Round::Down).0,
            Float::with_val_round(ORACLE, &r / &three, Round::Up).0,
        );
    }
}
#[test]
fn mpfr_decimal_cancellation_and_pi_extrema() {
    let mut b = MpIntervalBackend::new(Precision::default()).unwrap();
    for text in [
        "0.1",
        "-1.2345678901234567890123456789",
        "1e-1000",
        "1e1000",
    ] {
        let x = b.constant(&ExactConstant::Decimal(text.into())).unwrap();
        let lo = Float::with_val_round(ORACLE, Float::parse(text).unwrap(), Round::Down).0;
        let hi = Float::with_val_round(ORACLE, Float::parse(text).unwrap(), Round::Up).0;
        encloses(&x, lo, hi);
        let zero = b.sub(x.clone(), x).unwrap();
        assert!(b.contains_zero(&zero).unwrap());
    }
    let pi = b.pi().unwrap();
    let half = b.point(0.5).unwrap();
    let half_pi = b.mul(pi, half).unwrap();
    let s = b.sin(half_pi).unwrap();
    encloses(&s, Float::with_val(ORACLE, 1), Float::with_val(ORACLE, 1));
    let huge = BigFloat::from_i64(1, 256);
    let mut huge = huge;
    huge.set_exponent(4097);
    let x = b.singleton(&huge).unwrap();
    let r = exact_rug(&huge);
    encloses(
        &b.sin(x).unwrap(),
        Float::with_val_round(ORACLE, r.sin_ref(), Round::Down).0,
        Float::with_val_round(ORACLE, r.sin_ref(), Round::Up).0,
    );
}
#[test]
fn mpfr_checks_second_derivative_enclosures() {
    let mut b = MpIntervalBackend::new(Precision {
        bits: 128,
        ..Default::default()
    })
    .unwrap();
    let x = b.point(0.5).unwrap();
    let mut jet = JetBackend(&mut b);
    let seed = jet.variable(x).unwrap();
    let out = jet.sin(seed).unwrap();
    let value = Float::with_val(ORACLE, 0.5);
    encloses(
        &out.value,
        Float::with_val_round(ORACLE, value.sin_ref(), Round::Down).0,
        Float::with_val_round(ORACLE, value.sin_ref(), Round::Up).0,
    );
    encloses(
        &out.first,
        Float::with_val_round(ORACLE, value.cos_ref(), Round::Down).0,
        Float::with_val_round(ORACLE, value.cos_ref(), Round::Up).0,
    );
    let lower = -Float::with_val_round(ORACLE, value.sin_ref(), Round::Up).0;
    let upper = -Float::with_val_round(ORACLE, value.sin_ref(), Round::Down).0;
    encloses(&out.second, lower, upper);
}
