#![forbid(unsafe_code)]
//! Reusable numerical kernels and statically selected arithmetic policies.
//!
//! FFT kernels retain binary64 arithmetic. FFTs use a fixed
//! caller-selected backend; roundoff is not a certificate of an exact result.
//! The default build and execution policy are sequential and scalar.

mod fft;
mod interval;
pub mod observer;
mod policy;

pub use fft::{ConvolutionWorkspace, FftBackend, FftDirection, FftWorkspace, Normalization};
pub use interval::Interval;
pub use num_complex::Complex64;
pub use policy::{Error, ExecutionPolicy, Limits, ResourceUsage, Result};

pub mod ad;
pub mod arithmetic;

pub mod roots;

pub mod shapes;
