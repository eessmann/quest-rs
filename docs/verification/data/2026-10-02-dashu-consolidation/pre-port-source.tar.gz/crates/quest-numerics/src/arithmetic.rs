#![allow(
    clippy::float_cmp,
    reason = "Exact endpoint equality and zero are mathematical predicates"
)]
#![allow(
    clippy::needless_pass_by_value,
    reason = "Backend operations own their scalar operands uniformly"
)]
#![allow(
    clippy::many_single_char_names,
    reason = "Conventional endpoint and rounding variables in interval formulas"
)]
#![allow(
    clippy::type_complexity,
    reason = "Backend associated types preserve static dispatch and endpoint pairing"
)]
//! Backend-owned checked arithmetic. Scalars may allocate and need not be Copy.
//! `CertifyingBackend` admits arithmetic only; arbitrary functions still require
//! an explicit mathematical enclosure premise.
use crate::Interval;
pub use crate::ad::{First, FirstBackend, Gradient, GradientBackend, Jet, JetBackend};
use astro_float::{BigFloat, Consts, Radix, RoundingMode};
use std::cmp::Ordering;
mod interchange;
pub use interchange::{BinaryRounding, exact_from_f64, to_f64};
#[derive(Debug, thiserror::Error)]
pub enum ArithmeticError {
    #[error("backend arithmetic: {0}")]
    Backend(astro_float::Error),
    #[error("nonfinite arithmetic")]
    Nonfinite,
    #[error("invalid arithmetic input: {0}")]
    Interchange(&'static str),
    #[error("outside domain of {0}")]
    Domain(&'static str),
    #[error("arithmetic resource limit: {0}")]
    Budget(&'static str),
    #[error("binary64 enclosure: {0}")]
    Interval(#[from] crate::Error),
}
impl From<astro_float::Error> for ArithmeticError {
    fn from(e: astro_float::Error) -> Self {
        Self::Backend(e)
    }
}
pub type ArithmeticResult<T> = Result<T, ArithmeticError>;
#[derive(Clone, Debug, PartialEq)]
pub enum ExactConstant {
    Binary64(f64),
    Integer(i64),
    Rational(i64, u64),
    Decimal(String),
    Ratio {
        numerator: String,
        denominator: String,
    },
}
/// Exponent and work limits apply before mathematical shortcuts.
///
/// Astro-float
/// rounds precision upwards to whole words. Operation counts exclude internal
/// transcendental iterations and allocations; this is a modeled work limit.
#[derive(Clone, Copy, Debug)]
pub struct Precision {
    pub bits: usize,
    pub max_abs_exponent: i32,
    pub max_operations: usize,
}
impl Default for Precision {
    fn default() -> Self {
        Self {
            bits: 256,
            max_abs_exponent: 1_000_000,
            max_operations: 10_000_000,
        }
    }
}
pub trait Backend {
    /// Admit a stored scalar without rounding or changing its value. Custom
    /// backends whose scalar type does not enforce validity must override this
    /// hook; the default trusts their scalar admission contract.
    /// # Errors
    /// Rejects invalid values or values outside the backend's resource policy.
    fn validate(&self, value: &Self::Scalar) -> Result<(), Self::Error> {
        let _ = value;
        Ok(())
    }

    /// Account inline bytes and allocations owned by a scalar.
    /// # Errors
    /// Rejects invalid scalars or accounting overflow.
    fn storage_bytes(&self, value: &Self::Scalar) -> Result<usize, Self::Error> {
        let _ = value;
        Ok(std::mem::size_of::<Self::Scalar>())
    }
    /// Upper bound for an output at this backend's selected precision.
    fn working_scalar_bytes(&self) -> usize {
        std::mem::size_of::<Self::Scalar>()
    }

    type Scalar: Clone;
    type Error: From<ArithmeticError>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn visit(&mut self) -> Result<(), Self::Error> {
        Ok(())
    }
    /// Reserve modeled work for an opaque kernel. The default preserves each
    /// visit's effects and stops at its first error; wrappers may reserve the
    /// whole batch conservatively before forwarding it to an inner backend.
    /// # Errors
    /// Propagates visit failures, including exhausted resource limits.
    fn charge(&mut self, work: usize) -> Result<(), Self::Error> {
        for _ in 0..work {
            self.visit()?;
        }
        Ok(())
    }
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn constant(&mut self, value: &ExactConstant) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn point(&mut self, value: f64) -> Result<Self::Scalar, Self::Error> {
        self.constant(&ExactConstant::Binary64(value))
    }
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn add(&mut self, a: Self::Scalar, b: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn sub(&mut self, a: Self::Scalar, b: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn mul(&mut self, a: Self::Scalar, b: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn div(&mut self, a: Self::Scalar, b: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn neg(&mut self, a: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn exp(&mut self, a: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn ln(&mut self, a: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn sin(&mut self, a: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn cos(&mut self, a: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn sqrt(&mut self, a: Self::Scalar) -> Result<Self::Scalar, Self::Error>;
}
/// Arithmetic on finite stored scalar values at a selected precision.
///
/// Implementations must validate finite inputs and implement the declared
/// mathematical arithmetic and functions at their selected precision and rounding
/// policy. Successful operations on the same stored operands denote the same
/// mathematical operation; mutable caches and work counters may affect cost or
/// resource errors, but must not change that meaning. `compare` returns `Equal`
/// exactly when the stored scalars have the same mathematical value (including
/// signed zeros). Polynomial support and numerical algorithms rely on these laws.
pub trait PointBackend: Backend {
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn compare(&self, a: &Self::Scalar, b: &Self::Scalar) -> Result<Ordering, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn to_f64(&self, a: &Self::Scalar) -> Result<f64, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn pi(&mut self) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn epsilon(&mut self) -> Result<Self::Scalar, Self::Error>;
    fn precision_bits(&self) -> usize;
}
pub trait EnclosureBackend: Backend {
    type Endpoint: Clone;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn singleton(&mut self, value: &Self::Endpoint) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn lower_endpoint(&self, value: &Self::Scalar) -> Result<Self::Endpoint, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn upper_endpoint(&self, value: &Self::Scalar) -> Result<Self::Endpoint, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn lower(&mut self, value: &Self::Scalar) -> Result<Self::Scalar, Self::Error> {
        let x = self.lower_endpoint(value)?;
        self.singleton(&x)
    }
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn upper(&mut self, value: &Self::Scalar) -> Result<Self::Scalar, Self::Error> {
        let x = self.upper_endpoint(value)?;
        self.singleton(&x)
    }
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn hull(&mut self, a: &Self::Scalar, b: &Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn intersection(
        &mut self,
        a: &Self::Scalar,
        b: &Self::Scalar,
    ) -> Result<Option<Self::Scalar>, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn contains_zero(&self, a: &Self::Scalar) -> Result<bool, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn is_zero(&self, a: &Self::Scalar) -> Result<bool, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn strict_subset(&self, a: &Self::Scalar, b: &Self::Scalar) -> Result<bool, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn same(&self, a: &Self::Scalar, b: &Self::Scalar) -> Result<bool, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn midpoint(&mut self, a: &Self::Scalar) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn bisect(
        &mut self,
        a: &Self::Scalar,
    ) -> Result<Option<(Self::Scalar, Self::Scalar)>, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn magnitude_lt_one(&self, a: &Self::Scalar) -> Result<bool, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn nonnegative(&self, a: &Self::Scalar) -> Result<bool, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn pi(&mut self) -> Result<Self::Scalar, Self::Error>;
    /// # Errors
    /// Rejects invalid domains, backend failures, or exhausted resource limits.
    fn width_le(
        &mut self,
        a: &Self::Scalar,
        tolerance: &Self::Endpoint,
    ) -> Result<bool, Self::Error>;
}
mod sealed {
    pub trait Sealed {}
}
/// Admission is sealed to audited enclosure arithmetic; point arithmetic cannot certify.
/// ```compile_fail
/// use quest_numerics::arithmetic::{CertifyingBackend,F64Backend};
/// fn require_proof<B:CertifyingBackend>() {}
/// require_proof::<F64Backend>();
/// ```
pub trait CertifyingBackend: EnclosureBackend + sealed::Sealed {}
#[derive(Default, Debug)]
pub struct F64Backend;
const fn finite(x: f64) -> ArithmeticResult<f64> {
    if x.is_finite() {
        Ok(x)
    } else {
        Err(ArithmeticError::Nonfinite)
    }
}
// Keep adaptive exact imports outside the tiny binary64/AD constant hot path.
fn round_exact_f64(c: &ExactConstant) -> ArithmeticResult<f64> {
    // Resolve rounding from an outward enclosure; a fixed intermediate
    // precision can double-round arbitrarily close to a binary64 midpoint.
    let mut bits = 256;
    loop {
        let mut b = MpIntervalBackend::new(Precision {
            bits,
            ..Precision::default()
        })?;
        let x = b.constant(c)?;
        let lo = to_f64(&x.lower, BinaryRounding::Nearest)?;
        let hi = to_f64(&x.upper, BinaryRounding::Nearest)?;
        if lo.to_bits() == hi.to_bits() {
            return finite(lo);
        }
        bits = bits
            .checked_mul(2)
            .ok_or(ArithmeticError::Budget("constant rounding"))?;
        if bits > 1_048_576 {
            return Err(ArithmeticError::Budget("constant rounding"));
        }
    }
}
impl Backend for F64Backend {
    fn charge(&mut self, _work: usize) -> Result<(), Self::Error> {
        Ok(())
    }

    fn validate(&self, value: &f64) -> ArithmeticResult<()> {
        finite(*value).map(|_| ())
    }

    type Scalar = f64;
    type Error = ArithmeticError;
    #[allow(
        clippy::as_conversions,
        clippy::cast_precision_loss,
        reason = "Rust integer-to-f64 conversion rounds this exact integer once"
    )]
    #[inline]
    fn constant(&mut self, c: &ExactConstant) -> ArithmeticResult<f64> {
        if let ExactConstant::Binary64(x) = c {
            return finite(*x);
        }
        if let ExactConstant::Integer(x) = c {
            return Ok(*x as f64);
        }
        round_exact_f64(c)
    }

    #[inline]
    fn point(&mut self, value: f64) -> ArithmeticResult<f64> {
        finite(value)
    }
    fn add(&mut self, a: f64, b: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(b)?;
        finite(a + b)
    }
    fn sub(&mut self, a: f64, b: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(b)?;
        finite(a - b)
    }
    fn mul(&mut self, a: f64, b: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(b)?;
        finite(a * b)
    }
    fn div(&mut self, a: f64, b: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(b)?;
        if b == 0.0 {
            return Err(ArithmeticError::Domain("division"));
        }
        finite(a / b)
    }
    fn neg(&mut self, a: f64) -> ArithmeticResult<f64> {
        finite(-a)
    }
    fn exp(&mut self, a: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(a.exp())
    }
    fn ln(&mut self, a: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        if a <= 0.0 {
            return Err(ArithmeticError::Domain("ln"));
        }
        finite(a.ln())
    }
    fn sqrt(&mut self, a: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        if a < 0.0 {
            return Err(ArithmeticError::Domain("sqrt"));
        }
        finite(a.sqrt())
    }
    fn sin(&mut self, a: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(a.sin())
    }
    fn cos(&mut self, a: f64) -> ArithmeticResult<f64> {
        finite(a)?;
        finite(a.cos())
    }
}
impl PointBackend for F64Backend {
    fn compare(&self, a: &f64, b: &f64) -> ArithmeticResult<Ordering> {
        finite(*a)?;
        finite(*b)?;
        Ok(if a == b {
            Ordering::Equal
        } else if a < b {
            Ordering::Less
        } else {
            Ordering::Greater
        })
    }
    fn to_f64(&self, a: &f64) -> ArithmeticResult<f64> {
        finite(*a)
    }
    fn pi(&mut self) -> ArithmeticResult<f64> {
        Ok(std::f64::consts::PI)
    }
    fn epsilon(&mut self) -> ArithmeticResult<f64> {
        Ok(f64::EPSILON)
    }
    fn precision_bits(&self) -> usize {
        53
    }
}
#[derive(Default, Debug)]
pub struct Interval64Backend;
fn enclose_exact_f64(c: &ExactConstant) -> ArithmeticResult<Interval> {
    let mut b = MpIntervalBackend::new(Precision::default())?;
    let x = b.constant(c)?;
    Ok(Interval::new(
        to_f64(&x.lower, BinaryRounding::Down)?,
        to_f64(&x.upper, BinaryRounding::Up)?,
    )?)
}
impl Backend for Interval64Backend {
    fn charge(&mut self, _work: usize) -> Result<(), Self::Error> {
        Ok(())
    }

    fn validate(&self, value: &Interval) -> ArithmeticResult<()> {
        // Construction and all operations preserve finite, ordered endpoints.
        Interval::new(value.lower(), value.upper())?;
        Ok(())
    }

    type Scalar = Interval;
    type Error = ArithmeticError;
    #[allow(
        clippy::as_conversions,
        clippy::cast_precision_loss,
        reason = "Integers within 2^53 are represented exactly in binary64"
    )]
    #[inline]
    fn constant(&mut self, c: &ExactConstant) -> ArithmeticResult<Interval> {
        if let ExactConstant::Binary64(x) = c {
            return Ok(Interval::point(*x)?);
        }
        if let ExactConstant::Integer(x) = c
            && x.unsigned_abs() <= 1_u64 << 53
        {
            return Ok(Interval::point(*x as f64)?);
        }
        enclose_exact_f64(c)
    }

    #[inline]
    fn point(&mut self, value: f64) -> ArithmeticResult<Interval> {
        Ok(Interval::point(value)?)
    }
    fn add(&mut self, a: Interval, b: Interval) -> ArithmeticResult<Interval> {
        Ok(a.checked_add(b)?)
    }
    fn sub(&mut self, a: Interval, b: Interval) -> ArithmeticResult<Interval> {
        Ok(a.checked_sub(b)?)
    }
    fn mul(&mut self, a: Interval, b: Interval) -> ArithmeticResult<Interval> {
        Ok(a.checked_mul(b)?)
    }
    fn div(&mut self, a: Interval, b: Interval) -> ArithmeticResult<Interval> {
        Ok(a.checked_div(b)?)
    }
    fn neg(&mut self, a: Interval) -> ArithmeticResult<Interval> {
        Ok(a.checked_neg()?)
    }
    fn exp(&mut self, a: Interval) -> ArithmeticResult<Interval> {
        Ok(a.exp()?)
    }
    fn ln(&mut self, a: Interval) -> ArithmeticResult<Interval> {
        Ok(a.ln()?)
    }
    fn sqrt(&mut self, a: Interval) -> ArithmeticResult<Interval> {
        Ok(a.sqrt()?)
    }
    fn sin(&mut self, a: Interval) -> ArithmeticResult<Interval> {
        Ok(a.sin()?)
    }
    fn cos(&mut self, a: Interval) -> ArithmeticResult<Interval> {
        Ok(a.cos()?)
    }
}
impl EnclosureBackend for Interval64Backend {
    fn width_le(&mut self, a: &Interval, t: &f64) -> ArithmeticResult<bool> {
        finite(*t)?;
        if *t < 0.0 {
            return Err(ArithmeticError::Domain("negative tolerance"));
        }
        let width = Interval::point(a.upper())?.checked_sub(Interval::point(a.lower())?)?;
        Ok(width.upper() <= *t)
    }
    type Endpoint = f64;
    fn singleton(&mut self, x: &f64) -> ArithmeticResult<Interval> {
        Ok(Interval::point(*x)?)
    }
    fn lower_endpoint(&self, x: &Interval) -> ArithmeticResult<f64> {
        Ok(x.lower())
    }
    fn upper_endpoint(&self, x: &Interval) -> ArithmeticResult<f64> {
        Ok(x.upper())
    }
    fn hull(&mut self, a: &Interval, b: &Interval) -> ArithmeticResult<Interval> {
        Ok(Interval::new(
            a.lower().min(b.lower()),
            a.upper().max(b.upper()),
        )?)
    }
    fn intersection(&mut self, a: &Interval, b: &Interval) -> ArithmeticResult<Option<Interval>> {
        let l = a.lower().max(b.lower());
        let u = a.upper().min(b.upper());
        if l > u {
            Ok(None)
        } else {
            Ok(Some(Interval::new(l, u)?))
        }
    }
    fn contains_zero(&self, a: &Interval) -> ArithmeticResult<bool> {
        Ok(a.contains(0.0))
    }
    fn is_zero(&self, a: &Interval) -> ArithmeticResult<bool> {
        Ok(a.lower() == 0.0 && a.upper() == 0.0)
    }
    fn strict_subset(&self, a: &Interval, b: &Interval) -> ArithmeticResult<bool> {
        Ok(a.lower() > b.lower() && a.upper() < b.upper())
    }
    fn same(&self, a: &Interval, b: &Interval) -> ArithmeticResult<bool> {
        Ok(a.lower() == b.lower() && a.upper() == b.upper())
    }
    fn midpoint(&mut self, a: &Interval) -> ArithmeticResult<Interval> {
        Ok(Interval::point(
            a.upper()
                .mul_add(0.5, a.lower() * 0.5)
                .clamp(a.lower(), a.upper()),
        )?)
    }
    fn bisect(&mut self, a: &Interval) -> ArithmeticResult<Option<(Interval, Interval)>> {
        let m = self.midpoint(a)?.lower();
        if m <= a.lower() || m >= a.upper() {
            return Ok(None);
        }
        Ok(Some((
            Interval::new(a.lower(), m)?,
            Interval::new(m, a.upper())?,
        )))
    }
    fn magnitude_lt_one(&self, a: &Interval) -> ArithmeticResult<bool> {
        Ok(a.lower() > -1.0 && a.upper() < 1.0)
    }
    fn nonnegative(&self, a: &Interval) -> ArithmeticResult<bool> {
        Ok(a.lower() >= 0.0)
    }
    fn pi(&mut self) -> ArithmeticResult<Interval> {
        let mut b = MpIntervalBackend::new(Precision::default())?;
        let x = b.pi()?;
        Ok(Interval::new(
            to_f64(&x.lower, BinaryRounding::Down)?,
            to_f64(&x.upper, BinaryRounding::Up)?,
        )?)
    }
}
impl sealed::Sealed for Interval64Backend {}
impl CertifyingBackend for Interval64Backend {}
/// Endpoints are exact stored dyadics; construction is backend checked.
#[derive(Clone, Debug)]
pub struct MpInterval {
    lower: BigFloat,
    upper: BigFloat,
}
impl MpInterval {
    #[must_use]
    pub const fn lower(&self) -> &BigFloat {
        &self.lower
    }
    #[must_use]
    pub const fn upper(&self) -> &BigFloat {
        &self.upper
    }
}
pub struct MpBackend {
    precision: Precision,
    constants: Consts,
    operations: usize,
}
impl MpBackend {
    /// # Errors
    /// Rejects unsupported precision, exponent policy, or backend allocation failures.
    pub fn new(mut precision: Precision) -> ArithmeticResult<Self> {
        if precision.bits < 64
            || precision.bits > 1_048_576
            || precision.max_abs_exponent < 1
            || precision.max_abs_exponent > astro_float::EXPONENT_MAX / 4
        {
            return Err(ArithmeticError::Budget("precision/exponent"));
        }
        precision.bits = precision
            .bits
            .div_ceil(astro_float::WORD_BIT_SIZE)
            .saturating_mul(astro_float::WORD_BIT_SIZE);
        Ok(Self {
            precision,
            constants: Consts::new()?,
            operations: 0,
        })
    }
    #[must_use]
    pub const fn precision(&self) -> Precision {
        self.precision
    }
    #[must_use]
    pub const fn operations(&self) -> usize {
        self.operations
    }
    const fn tick(&mut self) -> ArithmeticResult<()> {
        if self.operations >= self.precision.max_operations {
            return Err(ArithmeticError::Budget("operations"));
        }
        self.operations = self.operations.saturating_add(1);
        Ok(())
    }
    fn validate_value(&self, x: &BigFloat) -> ArithmeticResult<()> {
        if let Some(e) = x.err() {
            return Err(e.into());
        }
        if x.is_nan() || x.is_inf() {
            return Err(ArithmeticError::Nonfinite);
        }
        if !x.is_zero()
            && x.exponent()
                .is_some_and(|e| e.unsigned_abs() > self.precision.max_abs_exponent.unsigned_abs())
        {
            return Err(ArithmeticError::Budget("exponent"));
        }
        Ok(())
    }
    fn checked(&self, mut x: BigFloat) -> ArithmeticResult<BigFloat> {
        self.validate_value(&x)?;
        if x.is_zero() && x.inexact() {
            return Err(ArithmeticError::Budget("underflow"));
        }
        x.set_inexact(false);
        Ok(x)
    }
    fn parse(&mut self, s: &str, round: RoundingMode) -> ArithmeticResult<BigFloat> {
        if s.len() > self.precision.bits.saturating_mul(8) {
            return Err(ArithmeticError::Budget("constant digits"));
        }
        if !valid_decimal(s) {
            return Err(ArithmeticError::Interchange("decimal syntax"));
        }
        let exponent = s
            .split(['e', 'E'])
            .nth(1)
            .map(str::parse::<i64>)
            .transpose()
            .map_err(|_| ArithmeticError::Budget("decimal exponent"))?
            .unwrap_or(0);
        if exponent.unsigned_abs()
            > u64::from(self.precision.max_abs_exponent.unsigned_abs()).saturating_add(
                u64::try_from(s.len()).map_err(|_| ArithmeticError::Budget("constant length"))?,
            )
        {
            return Err(ArithmeticError::Budget("decimal exponent"));
        }
        let x = BigFloat::parse(
            s,
            Radix::Dec,
            self.precision.bits,
            round,
            &mut self.constants,
        );
        if x.is_zero()
            && s.split(['e', 'E'])
                .next()
                .is_some_and(|m| m.bytes().any(|c| matches!(c, b'1'..=b'9')))
        {
            return Err(ArithmeticError::Budget("constant underflow"));
        }
        self.checked(x)
    }
    fn import(&mut self, c: &ExactConstant, round: RoundingMode) -> ArithmeticResult<BigFloat> {
        match c {
            ExactConstant::Binary64(x) => {
                let p = u32::try_from(self.precision.bits)
                    .map_err(|_| ArithmeticError::Budget("precision"))?;
                let x = exact_from_f64(*x, p)?;
                self.checked(x)
            }
            ExactConstant::Integer(x) => self.checked(BigFloat::from_i64(*x, self.precision.bits)),
            ExactConstant::Decimal(s) => self.parse(s, round),
            ExactConstant::Rational(n, d) => {
                if *d == 0 {
                    return Err(ArithmeticError::Domain("rational denominator"));
                }
                let n = BigFloat::from_i64(*n, self.precision.bits);
                self.validate_value(&n)?;
                let d = BigFloat::from_u64(*d, self.precision.bits);
                self.validate_value(&d)?;
                self.checked(n.div(&d, self.precision.bits, round))
            }
            ExactConstant::Ratio {
                numerator,
                denominator,
            } => {
                if !valid_integer(numerator) || !valid_positive_integer(denominator) {
                    return Err(ArithmeticError::Interchange("integer ratio"));
                }
                // Enough bits to represent both decimal integers exactly, then one division.
                let p = numerator
                    .len()
                    .max(denominator.len())
                    .checked_mul(4)
                    .ok_or(ArithmeticError::Budget("constant digits"))?
                    .max(self.precision.bits);
                if p > self.precision.bits.saturating_mul(32) {
                    return Err(ArithmeticError::Budget("constant digits"));
                }
                let n = BigFloat::parse(
                    numerator,
                    Radix::Dec,
                    p,
                    RoundingMode::ToEven,
                    &mut self.constants,
                );
                self.validate_value(&n)?;
                let d = BigFloat::parse(
                    denominator,
                    Radix::Dec,
                    p,
                    RoundingMode::ToEven,
                    &mut self.constants,
                );
                self.validate_value(&d)?;
                if d.is_zero() {
                    return Err(ArithmeticError::Domain("rational denominator"));
                }
                self.checked(n.div(&d, self.precision.bits, round))
            }
        }
    }
}
fn valid_integer(s: &str) -> bool {
    let s = s
        .strip_prefix('-')
        .or_else(|| s.strip_prefix('+'))
        .unwrap_or(s);
    !s.is_empty() && s.bytes().all(|x| x.is_ascii_digit())
}
fn valid_positive_integer(s: &str) -> bool {
    valid_integer(s) && !s.starts_with('-') && s.bytes().any(|x| matches!(x, b'1'..=b'9'))
}
fn valid_decimal(s: &str) -> bool {
    let s = s
        .strip_prefix('-')
        .or_else(|| s.strip_prefix('+'))
        .unwrap_or(s);
    let mut parts = s.split(['e', 'E']);
    let m = parts.next().unwrap_or("");
    let exp = parts.next();
    if parts.next().is_some() || exp.is_some_and(|s| !valid_integer(s)) {
        return false;
    }
    let mut dots: usize = 0;
    let mut digits: usize = 0;
    for c in m.bytes() {
        if c == b'.' {
            dots = dots.saturating_add(1);
        } else if c.is_ascii_digit() {
            digits = digits.saturating_add(1);
        } else {
            return false;
        }
    }
    dots <= 1 && digits > 0
}
impl Backend for MpBackend {
    fn validate(&self, value: &BigFloat) -> ArithmeticResult<()> {
        self.validate_value(value)
    }

    fn storage_bytes(&self, value: &BigFloat) -> ArithmeticResult<usize> {
        self.validate_value(value)?;
        let (words, ..) = value.as_raw_parts().ok_or(ArithmeticError::Nonfinite)?;
        words
            .len()
            .checked_mul(std::mem::size_of::<astro_float::Word>())
            .and_then(|n| n.checked_add(std::mem::size_of::<BigFloat>()))
            .ok_or(ArithmeticError::Budget("scalar storage"))
    }
    fn working_scalar_bytes(&self) -> usize {
        self.precision
            .bits
            .div_ceil(8)
            .saturating_add(std::mem::size_of::<BigFloat>())
    }

    type Scalar = BigFloat;
    type Error = ArithmeticError;
    fn visit(&mut self) -> ArithmeticResult<()> {
        self.tick()
    }
    fn constant(&mut self, c: &ExactConstant) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.import(c, RoundingMode::ToEven)
    }
    fn add(&mut self, a: BigFloat, b: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        self.checked(a.add(&b, self.precision.bits, RoundingMode::ToEven))
    }
    fn sub(&mut self, a: BigFloat, b: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        self.checked(a.sub(&b, self.precision.bits, RoundingMode::ToEven))
    }
    fn mul(&mut self, a: BigFloat, b: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        self.checked(a.mul(&b, self.precision.bits, RoundingMode::ToEven))
    }
    fn div(&mut self, a: BigFloat, b: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        if b.is_zero() {
            return Err(ArithmeticError::Domain("division"));
        }
        self.checked(a.div(&b, self.precision.bits, RoundingMode::ToEven))
    }
    fn neg(&mut self, a: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        self.checked(a.neg())
    }
    fn sqrt(&mut self, a: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        if a.cmp(&BigFloat::new(self.precision.bits))
            .is_some_and(|x| x < 0)
        {
            return Err(ArithmeticError::Domain("sqrt"));
        }
        self.checked(a.sqrt(self.precision.bits, RoundingMode::ToEven))
    }
    fn exp(&mut self, a: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        let x = a.exp(
            self.precision.bits,
            RoundingMode::ToEven,
            &mut self.constants,
        );
        self.validate_value(&x)?;
        if x.is_zero() {
            return Err(ArithmeticError::Budget("exponential underflow"));
        }
        self.checked(x)
    }
    fn ln(&mut self, a: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        if a.cmp(&BigFloat::new(self.precision.bits))
            .is_some_and(|x| x <= 0)
        {
            return Err(ArithmeticError::Domain("ln"));
        }
        let x = a.ln(
            self.precision.bits,
            RoundingMode::ToEven,
            &mut self.constants,
        );
        self.checked(x)
    }
    fn sin(&mut self, a: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        let x = a.sin(
            self.precision.bits,
            RoundingMode::ToEven,
            &mut self.constants,
        );
        self.checked(x)
    }
    fn cos(&mut self, a: BigFloat) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        self.validate_value(&a)?;
        let x = a.cos(
            self.precision.bits,
            RoundingMode::ToEven,
            &mut self.constants,
        );
        self.checked(x)
    }
}
impl PointBackend for MpBackend {
    fn compare(&self, a: &BigFloat, b: &BigFloat) -> ArithmeticResult<Ordering> {
        self.validate_value(a)?;
        self.validate_value(b)?;
        Ok(a.cmp(b).ok_or(ArithmeticError::Nonfinite)?.cmp(&0))
    }
    fn to_f64(&self, a: &BigFloat) -> ArithmeticResult<f64> {
        self.validate_value(a)?;
        to_f64(a, BinaryRounding::Nearest)
    }
    fn pi(&mut self) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        let x = self.constants.pi(self.precision.bits, RoundingMode::ToEven);
        self.checked(x)
    }
    fn epsilon(&mut self) -> ArithmeticResult<BigFloat> {
        self.tick()?;
        let mut x = BigFloat::from_i64(1, self.precision.bits);
        x.set_exponent(2_i32.saturating_sub(
            i32::try_from(self.precision.bits).map_err(|_| ArithmeticError::Budget("precision"))?,
        ));
        self.checked(x)
    }
    fn precision_bits(&self) -> usize {
        self.precision.bits
    }
}
pub struct MpIntervalBackend {
    point: MpBackend,
}
impl MpIntervalBackend {
    /// # Errors
    /// Rejects unsupported precision, exponent policy, or backend allocation failures.
    pub fn new(precision: Precision) -> ArithmeticResult<Self> {
        Ok(Self {
            point: MpBackend::new(precision)?,
        })
    }
    #[must_use]
    pub const fn precision(&self) -> Precision {
        self.point.precision()
    }
    fn validate_value(&self, x: &MpInterval) -> ArithmeticResult<()> {
        self.point.validate_value(&x.lower)?;
        self.point.validate_value(&x.upper)?;
        if x.lower.cmp(&x.upper).is_none_or(|v| v > 0) {
            return Err(ArithmeticError::Domain("interval order"));
        }
        Ok(())
    }
    fn interval(&self, lower: BigFloat, upper: BigFloat) -> ArithmeticResult<MpInterval> {
        let lower = self.point.checked(lower)?;
        let upper = self.point.checked(upper)?;
        let x = MpInterval { lower, upper };
        self.validate_value(&x)?;
        Ok(x)
    }
    fn monotone<F, C>(
        &mut self,
        a: MpInterval,
        mut evaluate: F,
        check_lower: C,
    ) -> ArithmeticResult<MpInterval>
    where
        F: FnMut(&BigFloat, usize, RoundingMode, &mut Consts) -> ArithmeticResult<BigFloat>,
        C: FnOnce(&BigFloat) -> ArithmeticResult<()>,
    {
        self.point.tick()?;
        self.validate_value(&a)?;
        let p = self.point.precision.bits;
        let lo = evaluate(&a.lower, p, RoundingMode::Down, &mut self.point.constants)?;
        self.point.validate_value(&lo)?;
        check_lower(&lo)?;
        let hi = evaluate(&a.upper, p, RoundingMode::Up, &mut self.point.constants)?;
        self.interval(lo, hi)
    }
}
impl Backend for MpIntervalBackend {
    fn validate(&self, value: &MpInterval) -> ArithmeticResult<()> {
        self.validate_value(value)
    }

    fn storage_bytes(&self, value: &MpInterval) -> ArithmeticResult<usize> {
        self.validate_value(value)?;
        self.point
            .storage_bytes(&value.lower)?
            .checked_add(self.point.storage_bytes(&value.upper)?)
            .ok_or(ArithmeticError::Budget("interval storage"))
    }
    fn working_scalar_bytes(&self) -> usize {
        self.point
            .precision
            .bits
            .div_ceil(8)
            .saturating_add(std::mem::size_of::<BigFloat>())
            .saturating_mul(2)
    }

    type Scalar = MpInterval;
    type Error = ArithmeticError;
    fn visit(&mut self) -> ArithmeticResult<()> {
        self.point.tick()
    }
    fn constant(&mut self, c: &ExactConstant) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        let lo = self.point.import(c, RoundingMode::Down)?;
        let hi = self.point.import(c, RoundingMode::Up)?;
        self.interval(lo, hi)
    }
    fn add(&mut self, a: MpInterval, b: MpInterval) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        let p = self.point.precision.bits;
        self.interval(
            a.lower.add(&b.lower, p, RoundingMode::Down),
            a.upper.add(&b.upper, p, RoundingMode::Up),
        )
    }
    fn sub(&mut self, a: MpInterval, b: MpInterval) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        let p = self.point.precision.bits;
        self.interval(
            a.lower.sub(&b.upper, p, RoundingMode::Down),
            a.upper.sub(&b.lower, p, RoundingMode::Up),
        )
    }
    fn mul(&mut self, a: MpInterval, b: MpInterval) -> ArithmeticResult<MpInterval> {
        self.products(a, b, false)
    }
    fn div(&mut self, a: MpInterval, b: MpInterval) -> ArithmeticResult<MpInterval> {
        self.products(a, b, true)
    }
    fn neg(&mut self, a: MpInterval) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(&a)?;
        self.interval(a.upper.neg(), a.lower.neg())
    }
    fn exp(&mut self, a: MpInterval) -> ArithmeticResult<MpInterval> {
        self.monotone(
            a,
            |x, p, r, cc| Ok(x.exp(p, r, cc)),
            |lo| {
                if lo.is_zero() {
                    Err(ArithmeticError::Budget("exponential underflow"))
                } else {
                    Ok(())
                }
            },
        )
    }
    fn ln(&mut self, a: MpInterval) -> ArithmeticResult<MpInterval> {
        self.monotone(
            a,
            |x, p, r, cc| {
                if x.cmp(&BigFloat::new(p)).is_some_and(|v| v <= 0) {
                    return Err(ArithmeticError::Domain("ln/sqrt"));
                }
                Ok(x.ln(p, r, cc))
            },
            |_| Ok(()),
        )
    }
    fn sqrt(&mut self, a: MpInterval) -> ArithmeticResult<MpInterval> {
        self.monotone(
            a,
            |x, p, r, _| {
                if x.cmp(&BigFloat::new(p)).is_some_and(|v| v < 0) {
                    return Err(ArithmeticError::Domain("ln/sqrt"));
                }
                Ok(x.sqrt(p, r))
            },
            |_| Ok(()),
        )
    }
    fn sin(&mut self, a: MpInterval) -> ArithmeticResult<MpInterval> {
        self.trig(a, true)
    }
    fn cos(&mut self, a: MpInterval) -> ArithmeticResult<MpInterval> {
        self.trig(a, false)
    }
}
impl MpIntervalBackend {
    fn products(
        &mut self,
        a: MpInterval,
        b: MpInterval,
        divide: bool,
    ) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(&a)?;
        self.validate_value(&b)?;
        if divide && self.contains_zero(&b)? {
            return Err(ArithmeticError::Domain("division"));
        }
        let p = self.point.precision.bits;
        let mut lo = None;
        let mut hi = None;
        for x in [&a.lower, &a.upper] {
            for y in [&b.lower, &b.upper] {
                let l = self.point.checked(if divide {
                    x.div(y, p, RoundingMode::Down)
                } else {
                    x.mul(y, p, RoundingMode::Down)
                })?;
                let u = self.point.checked(if divide {
                    x.div(y, p, RoundingMode::Up)
                } else {
                    x.mul(y, p, RoundingMode::Up)
                })?;
                lo = Some(match lo {
                    None => l,
                    Some(v) => l.min(&v),
                });
                hi = Some(match hi {
                    None => u,
                    Some(v) => u.max(&v),
                });
            }
        }
        self.interval(
            lo.ok_or(ArithmeticError::Domain("product"))?,
            hi.ok_or(ArithmeticError::Domain("product"))?,
        )
    }
    /// Does this outward interval contain an integer? Truncation is exact. The
    /// adjustment is done at sufficient precision; huge uncertain reductions
    /// conservatively admit an extremum without converting an index to f64.
    fn integer_possible(&self, q: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(q)?;
        let p = self.point.precision.bits;
        let integer_bits = i32::try_from(p)
            .map_err(|_| ArithmeticError::Budget("integer bits"))?
            .saturating_sub(2);
        if [&q.lower, &q.upper]
            .iter()
            .any(|x| x.exponent().is_some_and(|e| e > integer_bits))
        {
            return Ok(true);
        }
        let one = BigFloat::from_i64(1, p);
        let mut ceil = self.point.checked(q.lower.int())?;
        let mut floor = self.point.checked(q.upper.int())?;
        if q.lower.is_positive() && !q.lower.is_int() {
            ceil = self.point.checked(ceil.add(&one, p, RoundingMode::Up))?;
        }
        if q.upper.is_negative() && !q.upper.is_int() {
            floor = self.point.checked(floor.sub(&one, p, RoundingMode::Down))?;
        }
        Ok(ceil.cmp(&floor).is_some_and(|v| v <= 0))
    }
    fn trig(&mut self, a: MpInterval, sine: bool) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(&a)?;
        let p = self.point.precision.bits;
        // Bound extrema first. Argument reduction uncertainty must not suppress them.
        let pi = self.pi()?;
        let q = self.div(a.clone(), pi)?;
        let two = self.point(2.0)?;
        let phase = self.point(if sine { 0.5 } else { 0.0 })?;
        let positive = self.sub(q.clone(), phase)?;
        let positive = self.div(positive, two.clone())?;
        let phase = self.point(if sine { -0.5 } else { 1.0 })?;
        let negative = self.sub(q, phase)?;
        let negative = self.div(negative, two)?;
        let has_max = self.integer_possible(&positive)?;
        let has_min = self.integer_possible(&negative)?;
        if has_max && has_min {
            return self.interval(BigFloat::from_i64(-1, p), BigFloat::from_i64(1, p));
        }
        let eval = |x: &BigFloat, r, cc: &mut Consts| {
            if sine {
                x.sin(p, r, cc)
            } else {
                x.cos(p, r, cc)
            }
        };
        let ll = eval(&a.lower, RoundingMode::Down, &mut self.point.constants);
        let ll = self.point.checked(ll)?;
        let ul = eval(&a.upper, RoundingMode::Down, &mut self.point.constants);
        let ul = self.point.checked(ul)?;
        let lu = eval(&a.lower, RoundingMode::Up, &mut self.point.constants);
        let lu = self.point.checked(lu)?;
        let uu = eval(&a.upper, RoundingMode::Up, &mut self.point.constants);
        let uu = self.point.checked(uu)?;
        self.interval(
            if has_min {
                BigFloat::from_i64(-1, p)
            } else {
                ll.min(&ul)
            },
            if has_max {
                BigFloat::from_i64(1, p)
            } else {
                lu.max(&uu)
            },
        )
    }
}
impl EnclosureBackend for MpIntervalBackend {
    fn width_le(&mut self, a: &MpInterval, t: &BigFloat) -> ArithmeticResult<bool> {
        self.point.tick()?;
        self.validate_value(a)?;
        self.point.validate_value(t)?;
        if t.is_negative() && !t.is_zero() {
            return Err(ArithmeticError::Domain("negative tolerance"));
        }
        let w = self.point.checked(a.upper.sub(
            &a.lower,
            self.point.precision.bits,
            RoundingMode::Up,
        ))?;
        Ok(w.cmp(t).is_some_and(|v| v <= 0))
    }
    type Endpoint = BigFloat;
    fn singleton(&mut self, x: &BigFloat) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.interval(x.clone(), x.clone())
    }
    fn lower_endpoint(&self, x: &MpInterval) -> ArithmeticResult<BigFloat> {
        self.validate_value(x)?;
        Ok(x.lower.clone())
    }
    fn upper_endpoint(&self, x: &MpInterval) -> ArithmeticResult<BigFloat> {
        self.validate_value(x)?;
        Ok(x.upper.clone())
    }
    fn hull(&mut self, a: &MpInterval, b: &MpInterval) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(a)?;
        self.validate_value(b)?;
        self.interval(a.lower.min(&b.lower), a.upper.max(&b.upper))
    }
    fn intersection(
        &mut self,
        a: &MpInterval,
        b: &MpInterval,
    ) -> ArithmeticResult<Option<MpInterval>> {
        self.point.tick()?;
        self.validate_value(a)?;
        self.validate_value(b)?;
        let lo = a.lower.max(&b.lower);
        let hi = a.upper.min(&b.upper);
        if lo.cmp(&hi).is_some_and(|v| v > 0) {
            Ok(None)
        } else {
            Ok(Some(self.interval(lo, hi)?))
        }
    }
    fn contains_zero(&self, a: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(a)?;
        Ok((a.lower.is_negative() || a.lower.is_zero())
            && (a.upper.is_positive() || a.upper.is_zero()))
    }
    fn is_zero(&self, a: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(a)?;
        Ok(a.lower.is_zero() && a.upper.is_zero())
    }
    fn strict_subset(&self, a: &MpInterval, b: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(a)?;
        self.validate_value(b)?;
        Ok(a.lower.cmp(&b.lower).is_some_and(|v| v > 0)
            && a.upper.cmp(&b.upper).is_some_and(|v| v < 0))
    }
    fn same(&self, a: &MpInterval, b: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(a)?;
        self.validate_value(b)?;
        Ok(a.lower.cmp(&b.lower) == Some(0) && a.upper.cmp(&b.upper) == Some(0))
    }
    fn midpoint(&mut self, a: &MpInterval) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        self.validate_value(a)?;
        let p = self.point.precision.bits;
        let two = BigFloat::from_i64(2, p);
        let lo = self
            .point
            .checked(a.lower.div(&two, p, RoundingMode::ToEven))?;
        let hi = self
            .point
            .checked(a.upper.div(&two, p, RoundingMode::ToEven))?;
        let m = self
            .point
            .checked(lo.add(&hi, p, RoundingMode::ToEven))?
            .max(&a.lower)
            .min(&a.upper);
        self.interval(m.clone(), m)
    }
    fn bisect(&mut self, a: &MpInterval) -> ArithmeticResult<Option<(MpInterval, MpInterval)>> {
        self.validate_value(a)?;
        let m = self.midpoint(a)?.lower;
        if m.cmp(&a.lower).is_none_or(|v| v <= 0) || m.cmp(&a.upper).is_none_or(|v| v >= 0) {
            return Ok(None);
        }
        Ok(Some((
            self.interval(a.lower.clone(), m.clone())?,
            self.interval(m, a.upper.clone())?,
        )))
    }
    fn magnitude_lt_one(&self, a: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(a)?;
        let one = BigFloat::from_i64(1, self.point.precision.bits);
        Ok(a.lower.abs_cmp(&one).is_some_and(|v| v < 0)
            && a.upper.abs_cmp(&one).is_some_and(|v| v < 0))
    }
    fn nonnegative(&self, a: &MpInterval) -> ArithmeticResult<bool> {
        self.validate_value(a)?;
        Ok(!a.lower.is_negative() || a.lower.is_zero())
    }
    fn pi(&mut self) -> ArithmeticResult<MpInterval> {
        self.point.tick()?;
        let p = self.point.precision.bits;
        let lo = self.point.constants.pi(p, RoundingMode::Down);
        self.point.validate_value(&lo)?;
        let hi = self.point.constants.pi(p, RoundingMode::Up);
        self.interval(lo, hi)
    }
}
impl sealed::Sealed for MpIntervalBackend {}
impl CertifyingBackend for MpIntervalBackend {}

mod budget;
pub use budget::{Budget, BudgetedBackend};
