#pragma once

#include "quest-sys/src/lib.rs.h"
#include "quest_bindings.hpp"

namespace quest_sys {

void apply_comp_matr1(Qureg& qureg,
                      std::int32_t target,
                      const CompMatr1& matrix);
void apply_comp_matr2(Qureg& qureg,
                      std::int32_t target1,
                      std::int32_t target2,
                      const CompMatr2& matrix);
void apply_controlled_comp_matr(Qureg& qureg,
                                std::int32_t control,
                                rust::Slice<const std::int32_t> targets,
                                const CompMatr& matr);
void apply_controlled_comp_matr1(Qureg& qureg,
                                 std::int32_t control,
                                 std::int32_t target,
                                 const CompMatr1& matrix);
void apply_controlled_comp_matr2(Qureg& qureg,
                                 std::int32_t control,
                                 std::int32_t target1,
                                 std::int32_t target2,
                                 const CompMatr2& matr);
void apply_controlled_diag_matr(Qureg& qureg,
                                std::int32_t control,
                                rust::Slice<const std::int32_t> targets,
                                const DiagMatr& matrix);
void apply_controlled_diag_matr1(Qureg& qureg,
                                 std::int32_t control,
                                 std::int32_t target,
                                 const DiagMatr1& matr);
void apply_controlled_diag_matr2(Qureg& qureg,
                                 std::int32_t control,
                                 std::int32_t target1,
                                 std::int32_t target2,
                                 const DiagMatr2& matr);
void apply_controlled_diag_matr_power(Qureg& qureg,
                                      std::int32_t control,
                                      rust::Slice<const std::int32_t> targets,
                                      const DiagMatr& matrix,
                                      QuestComplex exponent);
void apply_controlled_hadamard(Qureg& qureg,
                               std::int32_t control,
                               std::int32_t target);
void apply_controlled_multi_qubit_not(Qureg& qureg,
                                      std::int32_t control,
                                      rust::Slice<const std::int32_t> targets);
void apply_controlled_pauli_gadget(Qureg& qureg,
                                   std::int32_t control,
                                   const PauliStr& str_arg,
                                   double angle);
void apply_controlled_pauli_str(Qureg& qureg,
                                std::int32_t control,
                                const PauliStr& str_arg);
void apply_controlled_pauli_x(Qureg& qureg,
                              std::int32_t control,
                              std::int32_t target);
void apply_controlled_pauli_y(Qureg& qureg,
                              std::int32_t control,
                              std::int32_t target);
void apply_controlled_pauli_z(Qureg& qureg,
                              std::int32_t control,
                              std::int32_t target);
void apply_controlled_phase_gadget(Qureg& qureg,
                                   std::int32_t control,
                                   rust::Slice<const std::int32_t> targets,
                                   double angle);
void apply_controlled_rotate_around_axis(Qureg& qureg,
                                         std::int32_t ctrl,
                                         std::int32_t targ,
                                         double angle,
                                         double axisX,
                                         double axisY,
                                         double axisZ);
void apply_controlled_rotate_x(Qureg& qureg,
                               std::int32_t control,
                               std::int32_t target,
                               double angle);
void apply_controlled_rotate_y(Qureg& qureg,
                               std::int32_t control,
                               std::int32_t target,
                               double angle);
void apply_controlled_rotate_z(Qureg& qureg,
                               std::int32_t control,
                               std::int32_t target,
                               double angle);
void apply_controlled_s(Qureg& qureg,
                        std::int32_t control,
                        std::int32_t target);
void apply_controlled_sqrt_swap(Qureg& qureg,
                                std::int32_t control,
                                std::int32_t qubit1,
                                std::int32_t qubit2);
void apply_controlled_swap(Qureg& qureg,
                           std::int32_t control,
                           std::int32_t qubit1,
                           std::int32_t qubit2);
void apply_controlled_t(Qureg& qureg,
                        std::int32_t control,
                        std::int32_t target);
void apply_diag_matr(Qureg& qureg,
                     rust::Slice<const std::int32_t> targets,
                     const DiagMatr& matrix);
void apply_diag_matr1(Qureg& qureg, std::int32_t target, const DiagMatr1& matr);
void apply_diag_matr2(Qureg& qureg,
                      std::int32_t target1,
                      std::int32_t target2,
                      const DiagMatr2& matr);
void apply_diag_matr_power(Qureg& qureg,
                           rust::Slice<const std::int32_t> targets,
                           const DiagMatr& matrix,
                           QuestComplex exponent);
double apply_forced_multi_qubit_measurement(
    Qureg& qureg,
    rust::Slice<const std::int32_t> qubits,
    rust::Slice<const std::int32_t> outcomes);
double apply_forced_qubit_measurement(Qureg& qureg,
                                      std::int32_t target,
                                      std::int32_t outcome);
void apply_full_quantum_fourier_transform(Qureg& qureg, bool inverse);
void apply_full_state_diag_matr(Qureg& qureg, const FullStateDiagMatr& matrix);
void apply_full_state_diag_matr_power(Qureg& qureg,
                                      const FullStateDiagMatr& matrix,
                                      QuestComplex exponent);
void apply_multi_controlled_comp_matr(Qureg& qureg,
                                      rust::Slice<const std::int32_t> controls,
                                      rust::Slice<const std::int32_t> targets,
                                      const CompMatr& matr);
void apply_multi_controlled_comp_matr1(Qureg& qureg,
                                       rust::Slice<const std::int32_t> controls,
                                       std::int32_t target,
                                       const CompMatr1& matrix);
void apply_multi_controlled_comp_matr2(Qureg& qureg,
                                       rust::Slice<const std::int32_t> controls,
                                       std::int32_t target1,
                                       std::int32_t target2,
                                       const CompMatr2& matr);
void apply_multi_controlled_diag_matr(Qureg& qureg,
                                      rust::Slice<const std::int32_t> controls,
                                      rust::Slice<const std::int32_t> targets,
                                      const DiagMatr& matrix);
void apply_multi_controlled_diag_matr1(Qureg& qureg,
                                       rust::Slice<const std::int32_t> controls,
                                       std::int32_t target,
                                       const DiagMatr1& matr);
void apply_multi_controlled_diag_matr2(Qureg& qureg,
                                       rust::Slice<const std::int32_t> controls,
                                       std::int32_t target1,
                                       std::int32_t target2,
                                       const DiagMatr2& matr);
void apply_multi_controlled_diag_matr_power(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> targets,
    const DiagMatr& matrix,
    QuestComplex exponent);
void apply_multi_controlled_hadamard(Qureg& qureg,
                                     rust::Slice<const std::int32_t> controls,
                                     std::int32_t target);
void apply_multi_controlled_multi_qubit_not(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> targets);
void apply_multi_controlled_pauli_gadget(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    const PauliStr& str_arg,
    double angle);
void apply_multi_controlled_pauli_str(Qureg& qureg,
                                      rust::Slice<const std::int32_t> controls,
                                      const PauliStr& str_arg);
void apply_multi_controlled_pauli_x(Qureg& qureg,
                                    rust::Slice<const std::int32_t> controls,
                                    std::int32_t target);
void apply_multi_controlled_pauli_y(Qureg& qureg,
                                    rust::Slice<const std::int32_t> controls,
                                    std::int32_t target);
void apply_multi_controlled_pauli_z(Qureg& qureg,
                                    rust::Slice<const std::int32_t> controls,
                                    std::int32_t target);
void apply_multi_controlled_phase_gadget(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> targets,
    double angle);
void apply_multi_controlled_rotate_around_axis(
    Qureg& qureg,
    rust::Slice<const std::int32_t> ctrls,
    std::int32_t targ,
    double angle,
    double axisX,
    double axisY,
    double axisZ);
void apply_multi_controlled_rotate_x(Qureg& qureg,
                                     rust::Slice<const std::int32_t> controls,
                                     std::int32_t target,
                                     double angle);
void apply_multi_controlled_rotate_y(Qureg& qureg,
                                     rust::Slice<const std::int32_t> controls,
                                     std::int32_t target,
                                     double angle);
void apply_multi_controlled_rotate_z(Qureg& qureg,
                                     rust::Slice<const std::int32_t> controls,
                                     std::int32_t target,
                                     double angle);
void apply_multi_controlled_s(Qureg& qureg,
                              rust::Slice<const std::int32_t> controls,
                              std::int32_t target);
void apply_multi_controlled_sqrt_swap(Qureg& qureg,
                                      rust::Slice<const std::int32_t> controls,
                                      std::int32_t qubit1,
                                      std::int32_t qubit2);
void apply_multi_controlled_swap(Qureg& qureg,
                                 rust::Slice<const std::int32_t> controls,
                                 std::int32_t qubit1,
                                 std::int32_t qubit2);
void apply_multi_controlled_t(Qureg& qureg,
                              rust::Slice<const std::int32_t> controls,
                              std::int32_t target);
std::int64_t apply_multi_qubit_measurement(
    Qureg& qureg,
    rust::Slice<const std::int32_t> qubits);
void apply_multi_qubit_not(Qureg& qureg,
                           rust::Slice<const std::int32_t> targets);
void apply_multi_qubit_phase_flip(Qureg& qureg,
                                  rust::Slice<const std::int32_t> targets);
void apply_multi_qubit_phase_shift(Qureg& qureg,
                                   rust::Slice<const std::int32_t> targets,
                                   double angle);
void apply_multi_qubit_projector(Qureg& qureg,
                                 rust::Slice<const std::int32_t> qubits,
                                 rust::Slice<const std::int32_t> outcomes);
void apply_multi_state_controlled_comp_matr(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    rust::Slice<const std::int32_t> targets,
    const CompMatr& matr);
void apply_multi_state_controlled_comp_matr1(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target,
    const CompMatr1& matrix);
void apply_multi_state_controlled_comp_matr2(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target1,
    std::int32_t target2,
    const CompMatr2& matr);
void apply_multi_state_controlled_diag_matr(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    rust::Slice<const std::int32_t> targets,
    const DiagMatr& matrix);
void apply_multi_state_controlled_diag_matr1(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target,
    const DiagMatr1& matr);
void apply_multi_state_controlled_diag_matr2(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target1,
    std::int32_t target2,
    const DiagMatr2& matr);
void apply_multi_state_controlled_diag_matr_power(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    rust::Slice<const std::int32_t> targets,
    const DiagMatr& matrix,
    QuestComplex exponent);
void apply_multi_state_controlled_hadamard(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target);
void apply_multi_state_controlled_multi_qubit_not(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    rust::Slice<const std::int32_t> targets);
void apply_multi_state_controlled_pauli_gadget(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    const PauliStr& str_arg,
    double angle);
void apply_multi_state_controlled_pauli_str(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    const PauliStr& str_arg);
void apply_multi_state_controlled_pauli_x(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target);
void apply_multi_state_controlled_pauli_y(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target);
void apply_multi_state_controlled_pauli_z(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target);
void apply_multi_state_controlled_phase_gadget(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    rust::Slice<const std::int32_t> targets,
    double angle);
void apply_multi_state_controlled_rotate_around_axis(
    Qureg& qureg,
    rust::Slice<const std::int32_t> ctrls,
    rust::Slice<const std::int32_t> states,
    std::int32_t targ,
    double angle,
    double axisX,
    double axisY,
    double axisZ);
void apply_multi_state_controlled_rotate_x(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target,
    double angle);
void apply_multi_state_controlled_rotate_y(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target,
    double angle);
void apply_multi_state_controlled_rotate_z(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t target,
    double angle);
void apply_multi_state_controlled_s(Qureg& qureg,
                                    rust::Slice<const std::int32_t> controls,
                                    rust::Slice<const std::int32_t> states,
                                    std::int32_t target);
void apply_multi_state_controlled_sqrt_swap(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    std::int32_t qubit1,
    std::int32_t qubit2);
void apply_multi_state_controlled_swap(Qureg& qureg,
                                       rust::Slice<const std::int32_t> controls,
                                       rust::Slice<const std::int32_t> states,
                                       std::int32_t qubit1,
                                       std::int32_t qubit2);
void apply_multi_state_controlled_t(Qureg& qureg,
                                    rust::Slice<const std::int32_t> controls,
                                    rust::Slice<const std::int32_t> states,
                                    std::int32_t target);
void apply_non_unitary_pauli_gadget(Qureg& qureg,
                                    const PauliStr& str_arg,
                                    QuestComplex angle);
void apply_pauli_gadget(Qureg& qureg, const PauliStr& str_arg, double angle);
void apply_pauli_str(Qureg& qureg, const PauliStr& str_arg);
void apply_phase_flip(Qureg& qureg, std::int32_t target);
void apply_phase_gadget(Qureg& qureg,
                        rust::Slice<const std::int32_t> targets,
                        double angle);
void apply_phase_shift(Qureg& qureg, std::int32_t target, double angle);
void apply_quantum_fourier_transform(Qureg& qureg,
                                     rust::Slice<const std::int32_t> targets,
                                     bool inverse);
void apply_qubit_projector(Qureg& qureg,
                           std::int32_t target,
                           std::int32_t outcome);
void apply_rotate_around_axis(Qureg& qureg,
                              std::int32_t target,
                              double angle,
                              double axisX,
                              double axisY,
                              double axisZ);
void apply_rotate_x(Qureg& qureg, std::int32_t target, double angle);
void apply_rotate_y(Qureg& qureg, std::int32_t target, double angle);
void apply_rotate_z(Qureg& qureg, std::int32_t target, double angle);
void apply_s(Qureg& qureg, std::int32_t target);
void apply_sqrt_swap(Qureg& qureg, std::int32_t qubit1, std::int32_t qubit2);
void apply_swap(Qureg& qureg, std::int32_t qubit1, std::int32_t qubit2);
void apply_t(Qureg& qureg, std::int32_t target);
void apply_trotterized_controlled_pauli_str_sum_gadget(Qureg& qureg,
                                                       std::int32_t control,
                                                       const PauliStrSum& sum,
                                                       double angle,
                                                       std::int32_t order,
                                                       std::int32_t reps,
                                                       bool permuteTerms);
void apply_trotterized_imaginary_time_evolution(Qureg& qureg,
                                                const PauliStrSum& hamil,
                                                double tau,
                                                std::int32_t order,
                                                std::int32_t reps,
                                                bool permuteTerms);
void apply_trotterized_multi_controlled_pauli_str_sum_gadget(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    const PauliStrSum& sum,
    double angle,
    std::int32_t order,
    std::int32_t reps,
    bool permuteTerms);
void apply_trotterized_multi_state_controlled_pauli_str_sum_gadget(
    Qureg& qureg,
    rust::Slice<const std::int32_t> controls,
    rust::Slice<const std::int32_t> states,
    const PauliStrSum& sum,
    double angle,
    std::int32_t order,
    std::int32_t reps,
    bool permuteTerms);
void apply_trotterized_non_unitary_pauli_str_sum_gadget(Qureg& qureg,
                                                        const PauliStrSum& sum,
                                                        QuestComplex angle,
                                                        std::int32_t order,
                                                        std::int32_t reps,
                                                        bool permuteTerms);
void apply_trotterized_pauli_str_sum_gadget(Qureg& qureg,
                                            const PauliStrSum& sum,
                                            double angle,
                                            std::int32_t order,
                                            std::int32_t reps,
                                            bool permuteTerms);
void apply_two_qubit_phase_flip(Qureg& qureg,
                                std::int32_t target1,
                                std::int32_t target2);
void apply_two_qubit_phase_shift(Qureg& qureg,
                                 std::int32_t target1,
                                 std::int32_t target2,
                                 double angle);
double calc_expec_full_state_diag_matr(const Qureg& qureg,
                                       const FullStateDiagMatr& matr);
double calc_expec_full_state_diag_matr_power(const Qureg& qureg,
                                             const FullStateDiagMatr& matrix,
                                             double exponent);
QuestComplex calc_expec_non_hermitian_full_state_diag_matr(
    const Qureg& qureg,
    const FullStateDiagMatr& matr);
QuestComplex calc_expec_non_hermitian_full_state_diag_matr_power(
    const Qureg& qureg,
    const FullStateDiagMatr& matrix,
    QuestComplex exponent);
QuestComplex calc_expec_non_hermitian_pauli_str_sum(const Qureg& qureg,
                                                    const PauliStrSum& sum);
double calc_expec_pauli_str(const Qureg& qureg, const PauliStr& str_arg);
double calc_expec_pauli_str_sum(const Qureg& qureg, const PauliStrSum& sum);
double calc_fidelity(const Qureg& qureg, const Qureg& other);
QuestComplex calc_inner_product(const Qureg& qureg, const Qureg& other);
std::unique_ptr<Qureg> calc_partial_trace(
    const Qureg& qureg,
    rust::Slice<const std::int32_t> traceOutQubits);
double calc_prob_of_basis_state(const Qureg& qureg, std::int64_t index);
double calc_prob_of_multi_qubit_outcome(
    const Qureg& qureg,
    rust::Slice<const std::int32_t> qubits,
    rust::Slice<const std::int32_t> outcomes);
double calc_prob_of_qubit_outcome(const Qureg& qureg,
                                  std::int32_t qubit,
                                  std::int32_t outcome);
rust::Vec<double> calc_probs_of_all_multi_qubit_outcomes(
    const Qureg& qureg,
    rust::Slice<const std::int32_t> qubits);
double calc_purity(const Qureg& qureg);
std::unique_ptr<Qureg> calc_reduced_density_matrix(
    const Qureg& qureg,
    rust::Slice<const std::int32_t> retainQubits);
void clear_qu_est_gpu_cache();
std::unique_ptr<Qureg> create_clone_qureg(const Qureg& qureg);
std::unique_ptr<FullStateDiagMatr> create_custom_full_state_diag_matr(
    std::int32_t numQubits,
    std::int32_t useDistrib,
    std::int32_t useGpuAccel,
    std::int32_t useMultithread);
std::unique_ptr<Qureg> create_custom_qureg(std::int32_t numQubits,
                                           std::int32_t isDensMatr,
                                           std::int32_t useDistrib,
                                           std::int32_t useGpuAccel,
                                           std::int32_t useMultithread);
std::unique_ptr<DiagMatr> create_diag_matr(std::int32_t numQubits);
std::unique_ptr<Qureg> create_forced_density_qureg(std::int32_t numQubits);
std::unique_ptr<Qureg> create_forced_qureg(std::int32_t numQubits);
std::unique_ptr<FullStateDiagMatr> create_full_state_diag_matr(
    std::int32_t numQubits);
std::unique_ptr<FullStateDiagMatr>
create_full_state_diag_matr_from_pauli_str_sum(const PauliStrSum& in_arg);
std::unique_ptr<DiagMatr> create_inline_diag_matr(
    std::int32_t numQb,
    rust::Slice<const QuestComplex> elems);
std::unique_ptr<PauliStrSum> create_pauli_str_sum_from_file(rust::Str fn);
std::unique_ptr<PauliStrSum> create_pauli_str_sum_from_reversed_file(
    rust::Str fn);
std::unique_ptr<Qureg> create_qureg_from_file(rust::Str fn);
QuestComplex get_density_qureg_amp(const Qureg& qureg,
                                   std::int64_t row,
                                   std::int64_t column);
std::unique_ptr<DiagMatr1> get_diag_matr1(
    rust::Slice<const QuestComplex> in_arg);
std::unique_ptr<DiagMatr2> get_diag_matr2(
    rust::Slice<const QuestComplex> in_arg);
std::unique_ptr<PauliStr> get_pauli_str_from_string(rust::Str paulis);
std::unique_ptr<PauliStr> get_pauli_str(
    rust::Str paulis,
    rust::Slice<const std::int32_t> indices);
std::int64_t get_qu_est_gpu_cache_size();
std::int32_t get_qu_est_num_gpu_threads_per_block();
std::int32_t get_qu_est_num_seeds();
double get_qu_est_validation_epsilon();
void init_blank_state(Qureg& qureg);
void init_classical_state(Qureg& qureg, std::int64_t stateInd);
void init_debug_state(Qureg& qureg);
void init_pure_state(Qureg& qureg, const Qureg& pure);
void init_random_mixed_state(Qureg& qureg, std::int64_t numPureStates);
void init_random_pure_state(Qureg& qureg);
void leftapply_comp_matr1(Qureg& qureg,
                          std::int32_t target,
                          const CompMatr1& matrix);
void leftapply_comp_matr2(Qureg& qureg,
                          std::int32_t target1,
                          std::int32_t target2,
                          const CompMatr2& matr);
void leftapply_diag_matr(Qureg& qureg,
                         rust::Slice<const std::int32_t> targets,
                         const DiagMatr& matrix);
void leftapply_diag_matr1(Qureg& qureg,
                          std::int32_t target,
                          const DiagMatr1& matr);
void leftapply_diag_matr2(Qureg& qureg,
                          std::int32_t target1,
                          std::int32_t target2,
                          const DiagMatr2& matr);
void leftapply_diag_matr_power(Qureg& qureg,
                               rust::Slice<const std::int32_t> targets,
                               const DiagMatr& matrix,
                               QuestComplex exponent);
void leftapply_full_state_diag_matr(Qureg& qureg,
                                    const FullStateDiagMatr& matrix);
void leftapply_full_state_diag_matr_power(Qureg& qureg,
                                          const FullStateDiagMatr& matrix,
                                          QuestComplex exponent);
void leftapply_multi_qubit_not(Qureg& qureg,
                               rust::Slice<const std::int32_t> targets);
void leftapply_multi_qubit_projector(Qureg& qureg,
                                     rust::Slice<const std::int32_t> qubits,
                                     rust::Slice<const std::int32_t> outcomes);
void leftapply_pauli_gadget(Qureg& qureg,
                            const PauliStr& str_arg,
                            double angle);
void leftapply_pauli_str(Qureg& qureg, const PauliStr& str_arg);
void leftapply_pauli_str_sum(Qureg& qureg,
                             const PauliStrSum& sum,
                             const Qureg& workspace);
void leftapply_pauli_x(Qureg& qureg, std::int32_t target);
void leftapply_pauli_y(Qureg& qureg, std::int32_t target);
void leftapply_pauli_z(Qureg& qureg, std::int32_t target);
void leftapply_phase_gadget(Qureg& qureg,
                            rust::Slice<const std::int32_t> targets,
                            double angle);
void leftapply_qubit_projector(Qureg& qureg,
                               std::int32_t qubit,
                               std::int32_t outcome);
void leftapply_swap(Qureg& qureg, std::int32_t qubit1, std::int32_t qubit2);
void mix_damping(Qureg& qureg, std::int32_t target, double prob);
void mix_depolarising(Qureg& qureg, std::int32_t target, double prob);
void mix_kraus_map(Qureg& qureg,
                   rust::Slice<const std::int32_t> targets,
                   const KrausMap& map);
void mix_paulis(Qureg& qureg,
                std::int32_t target,
                double probX,
                double probY,
                double probZ);
void mix_qureg(Qureg& qureg, const Qureg& other, double prob);
void mix_super_op(Qureg& qureg,
                  rust::Slice<const std::int32_t> targets,
                  const SuperOp& superop);
void mix_two_qubit_dephasing(Qureg& qureg,
                             std::int32_t target1,
                             std::int32_t target2,
                             double prob);
void mix_two_qubit_depolarising(Qureg& qureg,
                                std::int32_t target1,
                                std::int32_t target2,
                                double prob);
void report_comp_matr(const CompMatr& matrix);
void report_comp_matr1(const CompMatr1& matrix);
void report_comp_matr2(const CompMatr2& matrix);
void report_diag_matr(const DiagMatr& matrix);
void report_diag_matr1(const DiagMatr1& matrix);
void report_diag_matr2(const DiagMatr2& matrix);
void report_full_state_diag_matr(const FullStateDiagMatr& matr);
void report_kraus_map(const KrausMap& map);
void report_pauli_str(const PauliStr& str_arg);
void report_pauli_str_sum(const PauliStrSum& str_arg);
void report_qureg(const Qureg& qureg);
void report_qureg_params(const Qureg& qureg);
void report_scalar_real(rust::Str label, double num);
void report_scalar(rust::Str label, QuestComplex num);
void report_str(rust::Str str_arg);
void report_super_op(const SuperOp& op);
void rightapply_comp_matr1(Qureg& qureg,
                           std::int32_t target,
                           const CompMatr1& matrix);
void rightapply_comp_matr2(Qureg& qureg,
                           std::int32_t target1,
                           std::int32_t target2,
                           const CompMatr2& matrix);
void rightapply_diag_matr(Qureg& qureg,
                          rust::Slice<const std::int32_t> targets,
                          const DiagMatr& matrix);
void rightapply_diag_matr1(Qureg& qureg,
                           std::int32_t target,
                           const DiagMatr1& matrix);
void rightapply_diag_matr2(Qureg& qureg,
                           std::int32_t target1,
                           std::int32_t target2,
                           const DiagMatr2& matrix);
void rightapply_diag_matr_power(Qureg& qureg,
                                rust::Slice<const std::int32_t> targets,
                                const DiagMatr& matrix,
                                QuestComplex exponent);
void rightapply_full_state_diag_matr(Qureg& qureg,
                                     const FullStateDiagMatr& matrix);
void rightapply_full_state_diag_matr_power(Qureg& qureg,
                                           const FullStateDiagMatr& matrix,
                                           QuestComplex exponent);
void rightapply_multi_qubit_not(Qureg& qureg,
                                rust::Slice<const std::int32_t> targets);
void rightapply_multi_qubit_projector(Qureg& qureg,
                                      rust::Slice<const std::int32_t> qubits,
                                      rust::Slice<const std::int32_t> outcomes);
void rightapply_pauli_gadget(Qureg& qureg,
                             const PauliStr& str_arg,
                             double angle);
void rightapply_pauli_str(Qureg& qureg, const PauliStr& str_arg);
void rightapply_pauli_str_sum(Qureg& qureg,
                              const PauliStrSum& sum,
                              const Qureg& workspace);
void rightapply_pauli_x(Qureg& qureg, std::int32_t target);
void rightapply_pauli_y(Qureg& qureg, std::int32_t target);
void rightapply_pauli_z(Qureg& qureg, std::int32_t target);
void rightapply_phase_gadget(Qureg& qureg,
                             rust::Slice<const std::int32_t> targets,
                             double angle);
void rightapply_qubit_projector(Qureg& qureg,
                                std::int32_t qubit,
                                std::int32_t outcome);
void rightapply_swap(Qureg& qureg, std::int32_t qubit1, std::int32_t qubit2);
void save_qureg_to_file(Qureg& qureg, rust::Str arg1);
void set_density_qureg_flat_amps(Qureg& qureg,
                                 std::int64_t startInd,
                                 rust::Slice<const QuestComplex> amps);
void set_diag_matr(DiagMatr& out_arg, rust::Slice<const QuestComplex> in_arg);
void set_full_state_diag_matr(FullStateDiagMatr& out_arg,
                              std::int64_t startInd,
                              rust::Slice<const QuestComplex> in_arg);
void set_full_state_diag_matr_from_pauli_str_sum(FullStateDiagMatr& out_arg,
                                                 const PauliStrSum& in_arg);
void set_inline_diag_matr(DiagMatr& matr,
                          std::int32_t numQb,
                          rust::Slice<const QuestComplex> in_arg);
void set_inline_full_state_diag_matr(FullStateDiagMatr& matr,
                                     std::int64_t startInd,
                                     std::int64_t numElems,
                                     rust::Slice<const QuestComplex> in_arg);
void set_qu_est_max_num_reported_items(std::int64_t numRows,
                                       std::int64_t numCols);
void set_qu_est_max_num_reported_sig_figs(std::int32_t numSigFigs);
void set_qu_est_num_gpu_threads_per_block(std::int32_t numThreadsPerBlock);
void set_qu_est_num_reported_newlines(std::int32_t numNewlines);
void set_qu_est_reported_pauli_chars(rust::Str paulis);
void set_qu_est_reported_pauli_str_style(std::int32_t style);
void set_qu_est_seeds_to_default();
void set_qu_est_validation_epsilon(double eps);
void set_qu_est_validation_epsilon_to_default();
void set_qu_est_validation_on();
void set_qureg_amps(Qureg& qureg,
                    std::int64_t startInd,
                    rust::Slice<const QuestComplex> amps);
void set_qureg_to_clone(Qureg& outQureg, const Qureg& inQureg);
void set_qureg_to_partial_trace(Qureg& out_arg,
                                const Qureg& in_arg,
                                rust::Slice<const std::int32_t> traceOutQubits);
void set_qureg_to_pauli_str_sum(Qureg& qureg, const PauliStrSum& sum);
void set_qureg_to_reduced_density_matrix(
    Qureg& out_arg,
    const Qureg& in_arg,
    rust::Slice<const std::int32_t> retainQubits);
double set_qureg_to_renormalized(Qureg& qureg);
void sort_pauli_str_sum_lexicographic(PauliStrSum& sum);
void sort_pauli_str_sum_magnitude(PauliStrSum& sum);
void sync_comp_matr(CompMatr& matr);
void sync_diag_matr(DiagMatr& matr);
void sync_full_state_diag_matr(FullStateDiagMatr& matr);
void sync_kraus_map(KrausMap& map);
void sync_qureg_from_gpu(Qureg& qureg);
void sync_qureg_to_gpu(Qureg& qureg);
void sync_sub_qureg_from_gpu(Qureg& qureg,
                             std::int64_t localStartInd,
                             std::int64_t numLocalAmps);
void sync_sub_qureg_to_gpu(Qureg& qureg,
                           std::int64_t localStartInd,
                           std::int64_t numLocalAmps);
void sync_super_op(SuperOp& op);

}  // namespace quest_sys
